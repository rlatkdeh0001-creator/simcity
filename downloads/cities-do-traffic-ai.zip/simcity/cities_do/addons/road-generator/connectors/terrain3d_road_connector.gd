@tool
class_name RoadTerrain3DConnector
extends Node

enum Flatten_terrain_option {
	APPROXIMATE, ## Faster and supports falloff, but doesn't handle tilting well
	RAYCAST, ## Accurate and handles tilting, but doesn't have smooth falloth
	BOTH ## Apply the approximate method first, then the raycast method
}

const RoadSegment = preload("res://addons/road-generator/nodes/road_segment.gd")
const IntersectionNGon = preload("res://addons/road-generator/procgen/intersection_ngon.gd")

## Workaround to avoid typing errors for people who aren't using this connector
## https://github.com/TokisanGames/Terrain3D/blob/bbef16d70f7553caad9da956651336f592512406/src/terrain_3d_region.h#L17C3-L17C14
const TERRAIN_3D_MAPTYPE_HEIGHT:int = 0 # Terrain3DRegion.MapType.TYPE_HEIGHT
const TERRAIN_3D_MAPTYPE_CONTROL:int = 1 # Terrain3DRegion.MapType.TYPE_CONTROL

## Margin beyond road bounds when picking terrain regions to save for undo
const UNDO_BOUNDS_MARGIN:float = 4.0
# TODO: Replace with a deterministic check, e.g. the editor's version_changed signal
## Road updates this soon after an undo/redo are considered part of it
const UNDO_RESTORED_WINDOW_MSEC:int = 1000

# ------------------------------------------------------------------------------
#region Export and local vars
# ------------------------------------------------------------------------------


## Reference to the Terrain3D instance, to be flattened
@export var terrain:Node3D: #Terrain3D:
	set(value):
		terrain = value
		configure_road_update_signal()
		if is_node_ready():
			_skip_scene_load = false
## Reference to the RoadManager instance, read only
@export var road_manager:RoadManager:
	set(value):
		road_manager = value
		configure_road_update_signal()
		if is_node_ready():
			_skip_scene_load = false
## If enabled, auto refresh the terrain while manipulating roads.
@export var auto_refresh:bool = true:
	set(value):
		auto_refresh = value
		configure_road_update_signal()
## Vertical offset to help avoid z-fighting, negative values will sink the terrain underneath the road
@export var offset:float = -0.25
## Additional flattening to do beyond the edge of the road in meters
@export var edge_margin:float = 0.5
## The falloff to apply for height changes from the edge of the road.
## This falloff range begins beyond the edge of the road + edge margin
@export var edge_falloff:float = 2

@export var flatten_terrain_method :Flatten_terrain_option = Flatten_terrain_option.APPROXIMATE

## Create data for new terrain tiles when necessary.[br][br]
##
## If disabled, roads will only adjust heights for pre-existing data tiles.
# TODO: Add in future when feasible
#@export var expand_boundaries:bool = true

## Layer/mask used for editor raycasting, can be different from the runtime collision layers
@export_flags_3d_physics var raycast_layer:int = 2

## Immediately level the terrain to match roads
@export_tool_button("Refresh", "Callable") var refresh_action = do_full_refresh
## Cull geometry under roads for entire network (never done automatically)
@export_tool_button("Bake Holes", "Callable") var bake_holes_action = bake_holes

# If using Auto Refresh, how often to update the UI (lower values = heavier cpu use)
var refresh_timer: float = 0.05


var _pending_updates:Dictionary = {} # Hashset of RoadSegments to be updated; 4.4+ typing: RoadSegment,bool
var _next_refresh_parents:Array = [] # Array[Mesh]
var _container_unset_geo: Array[RoadContainer] = []
var _timer:SceneTreeTimer
var _mutex:Mutex = Mutex.new()
var _skip_scene_load: bool = true # Also directly referecned by plugin to ensure top-level refresh works
var _undoredo_full_refresh_pending: bool = false # Next refresh gets its own undo action, not merged
var _undoredo_restored_version: int = -1 # History version of the last undo/redo restore
var _undoredo_restored_msec: int = 0

var _height_map_cache: Dictionary = {}
var _reference_height_map_cache: Dictionary = {}
var _height_region_cache: Dictionary = {}
var _modified_height_regions: Dictionary = {}
var _missing_height_regions: Dictionary = {}
var _height_map_edit_active: bool = false


# ------------------------------------------------------------------------------
#endregion
#region Overrides
# ------------------------------------------------------------------------------



func _ready() -> void:
	configure_road_update_signal()


func _enter_tree() -> void:
	if is_node_ready():
		configure_road_update_signal.call_deferred()


func _exit_tree() -> void:
	_disconnect_signals()
	_skip_scene_load = true


## Any raycasting must be done from this function in case physics are threaded
func _physics_process(_delta:float) -> void:
	if _next_refresh_parents:
		_mutex.lock()
		var _mesh_parents := _next_refresh_parents.duplicate(true)
		var _unset_geo := _container_unset_geo.duplicate(true)
		_next_refresh_parents = []
		_container_unset_geo = []
		_mutex.unlock()
		refresh_roads(_mesh_parents)
		# Restore the geo setting where temporarily turned on
		for _rc in _unset_geo:
			_rc.create_geo = false


func _get_configuration_warnings() -> PackedStringArray:
	var warnings: PackedStringArray = []
	if not is_instance_valid(road_manager):
		warnings.append("Road manager not assigned for terrain flattening")
	if not is_instance_valid(terrain):
		warnings.append("Terrain not assigned for terrain flattening")
	elif not terrain.data or terrain.data.region_locations.size() == 0:
		warnings.append("No Terrain3D regions defined yet, add regions in Terrain3D first")
	return warnings


# ------------------------------------------------------------------------------
#endregion
#region Core functions
# ------------------------------------------------------------------------------


func is_configured() -> bool:
	var has_error:bool = false
	if not is_instance_valid(road_manager):
		push_warning("Road manager not assigned for terrain flattening")
		has_error = true
	if not is_instance_valid(terrain):
		push_warning("Terrain not assigned for terrain flattening")
		has_error = true
	elif not terrain.data or terrain.data.region_locations.size() == 0:
		push_warning("No Terrain3D regions defined yet, add regions in Terrain3D first")
		has_error = true
	return not has_error


func configure_road_update_signal() -> void:
	if not Engine.is_editor_hint():
		# Don't run outside of an editor context
		return
	if not is_instance_valid(road_manager):
		return

	# Handle signals from each RoadContainer when there are updated segments
	if auto_refresh and not road_manager.on_road_updated.is_connected(_on_manager_road_updated):
		road_manager.on_road_updated.connect(_on_manager_road_updated)
	elif not auto_refresh and road_manager.on_road_updated.is_connected(_on_manager_road_updated):
		road_manager.on_road_updated.disconnect(_on_manager_road_updated)
		
	# Handle transforms on containers themelves
	if auto_refresh and not road_manager.on_container_transformed.is_connected(_on_container_transform):
		road_manager.on_container_transformed.connect(_on_container_transform)
	elif not auto_refresh and road_manager.on_container_transformed.is_connected(_on_container_transform):
		road_manager.on_container_transformed.disconnect(_on_container_transform)


## Disconnects signals so avoid excessive refreshing if scene tab is opened again in the editor
func _disconnect_signals() -> void:
	if is_instance_valid(road_manager) and road_manager.on_road_updated.is_connected(_on_manager_road_updated):
		road_manager.on_road_updated.disconnect(_on_manager_road_updated)
	if is_instance_valid(road_manager) and road_manager.on_container_transformed.is_connected(_on_container_transform):
		road_manager.on_container_transformed.disconnect(_on_container_transform)


func do_full_refresh() -> void:
	if not is_configured():
		return
	configure_road_update_signal()
	var restart_geo_off: Array[RoadContainer] = []
	var init_auto_refresh: bool = auto_refresh
	for _container in road_manager.get_containers():
		_container = _container as RoadContainer

		_mutex.lock()
		if not _container.create_geo:
			init_auto_refresh = false
			_container.create_geo = true
			_container.rebuild_segments(true)
			init_auto_refresh = init_auto_refresh
			restart_geo_off.append(_container)
			
		#var mesh_parents: Array = []
		_next_refresh_parents += _container.get_intersections()
		_next_refresh_parents += _container.get_segments() # Always add RoadSegments last
		_undoredo_full_refresh_pending = true
		_mutex.unlock()


## Removes mesh under roads as a baking process.
func bake_holes() -> void:
	if not is_configured():
		return
	for _container in road_manager.get_containers():
		_container = _container as RoadContainer
		var segs:Array = _container.get_segments()
		for _seg in segs:
			cull_terrain_via_roadsegment(_seg)
	
	terrain.data.update_maps(TERRAIN_3D_MAPTYPE_CONTROL)


## Workaround helper to transform geo for intersection scenes or other
## scenarios where "create_geo" is turned off, by temporairly turning it on.
func _on_container_transform(container:RoadContainer) -> void:
	if not auto_refresh:
		return
	var did_set_geo := false
	if not container.create_geo:
		did_set_geo = true
		container.create_geo = true
		# This will trigger deferred updates which will have invalid instances,
		# but will be safely ignored
		container.rebuild_segments(true)
	# Must directly update terrain now on these segments, before they get
	# removed again when geo is turned off
	_mutex.lock()
	_next_refresh_parents += container.get_intersections()
	_next_refresh_parents += container.get_segments() # Always add RoadSegments last
	if did_set_geo:
		_container_unset_geo.append(container)
	_mutex.unlock()


func _on_manager_road_updated(segments: Array) -> void:
	if not road_manager or not terrain:
		return # one or the other is not defined
	if not road_manager.is_node_ready() or not terrain.is_node_ready():
		# Likely loading scene for the first time, and thus roads will be
		# generated but it's not expected to perform flattening
		return
	_schedule_refresh(segments)


## Accumulates road segments to be refreshed while an operation is in progress
func _schedule_refresh(segments: Array) -> void:
	if _skip_scene_load:
		_skip_scene_load = false
		return
	_mutex.lock()
	for _seg in segments:
		# Using a dictionary to accumulate updates to process
		_pending_updates[_seg] = true
	if not is_instance_valid(_timer):
		_timer = get_tree().create_timer(refresh_timer)
	else:
		pass
	if not _timer.timeout.is_connected(_refresh_scheduled_segments):
		_timer.timeout.connect(_refresh_scheduled_segments)
	_mutex.unlock()


func _refresh_scheduled_segments() -> void:
	if Input.is_mouse_button_pressed(MOUSE_BUTTON_LEFT):
		# updates may still be in progress, so just reset
		_mutex.lock()
		_timer = null
		call_deferred("_schedule_refresh", [])
		_mutex.unlock()
		return
	_mutex.lock()
	var _mesh_parents := _pending_updates.keys()
	_pending_updates.clear()
	_timer = null
	# Assigning to _next_refresh_parents effectively means the meshes will be
	# refreshed the next time the physics thread runs
	_next_refresh_parents += _mesh_parents
	_mutex.unlock()


## Refreshes all segments of road identified
##
## Order of segments should be first intersections if any, then road segments
## so that the combined flattening is proper.
func refresh_roads(mesh_parents: Array) -> void:
	if not is_configured():
		push_warning("Terrain-Road configuration invalid")
		return
	if not terrain.data:
		push_warning("No terrain data available (yet)")
		return
	if terrain.data.region_locations.size() == 0:
		push_warning("Refreshw arning: No Terrain3D regions defined yet, add regions in Terrain3D first")

	var own_action := _undoredo_full_refresh_pending
	_undoredo_full_refresh_pending = false
	var history := _get_editor_history()
	if history and not own_action and _is_undo_redo_update(history):
		# Terrain was already restored by the undo/redo itself
		return
	var heights_before := {}
	var merge_into_edit := false
	if history:
		heights_before = _copy_height_maps(_get_regions_reached(mesh_parents))
		if not own_action and not heights_before.is_empty():
			merge_into_edit = _open_merged_terrain_undo(history)

	begin_height_map_edit()
	var skip_repeat_refreshes: Array = []
	
	var segs: Array = [] # RoadSegment

	# First flatten all road intersections and gather their adjacent segments
	for _seg in mesh_parents:
		if not is_instance_valid(_seg):
			# Will happen (at a minimum) when handling RoadContainers which have
			# create geo turned off AND auto_refresh is on; creates an extra
			# deferred call to here when those segments are temporarily added,
			# but will be invalid by the time this function actually runs as
			# they are destroyed right away after a direct call to this func
			continue
		if _seg is RoadIntersection:
			var inter := _seg as RoadIntersection
			if inter.container.flatten_terrain and inter.flatten_terrain:
				flatten_terrain_via_intersection(inter)
				# Since the intersection flattening is a little too greedy,
				# must post-flatten the adjacent segments too, even if they
				# weren't scheduled
				var adj_segs = intersection_adjacent_segments(inter)
				segs += adj_segs
				# In case these segmetns were already in the list, avoid repeat
				# flattening them
				# TODO: handle case where one segment is directly connected to
				# two intersections
				skip_repeat_refreshes += inter.edge_points
			continue
		elif _seg is RoadSegment:
			segs.append(_seg)
	
	# Now flatten all accumulated segments
	for _seg in segs:
		if not is_instance_valid(_seg):
			continue
		_seg = _seg as RoadSegment
		if not _seg:
			continue
		if _seg in skip_repeat_refreshes:
			continue
		# check if this segment should be ignored
		if (
			not _seg.container.flatten_terrain
			or (not _seg.start_point.flatten_terrain and not _seg.end_point.flatten_terrain)
		):
			# print("Skipping ignored segment %s/%s" % [_seg.get_parent().name, _seg.name])
			continue
		#print("Refreshing %s/%s" % [_seg.get_parent().name, _seg.name])
		match flatten_terrain_method:
			Flatten_terrain_option.APPROXIMATE:
				flatten_terrain_via_roadsegment_approx(_seg)
			Flatten_terrain_option.RAYCAST:
				flatten_terrain_via_roadsegment_raycast(_seg)
			Flatten_terrain_option.BOTH:
				flatten_terrain_via_roadsegment_approx(_seg)
				flatten_terrain_via_roadsegment_raycast(_seg)
			_:
				flatten_terrain_via_roadsegment_approx(_seg)
		skip_repeat_refreshes.append(_seg)

	finish_height_map_edit()

	if history:
		_add_terrain_undo(heights_before, merge_into_edit)


## Flatten and Culling Methods
func flatten_terrain_via_roadsegment_raycast(segment: RoadSegment) -> void:
	if not validate_segment(segment):
		return
	
	# add extra width to the shoulders for the raycasting,
	# TODO: Account for alignment options
	var buffer = edge_margin
	
	var mesh := segment.road_mesh.mesh
	if mesh == null:
		return
	
	# create new collision mesh for eventual raycasting
	# TODO: This MUST be done in the process_physics function to avoid errors
	# for users with physics processing on another thread.
	var space_states: Array[PhysicsDirectSpaceState3D] = []
	var revert_layers: Array = []
	for ch in segment.road_mesh.get_children():
		var sbody := ch as StaticBody3D # Set to null if casting fails
		if not sbody:
			continue
		# TODO: This may override the native assigned layers
		revert_layers.append([sbody, sbody.collision_layer, sbody.collision_mask])
		sbody.collision_layer = raycast_layer
		sbody.collision_mask = raycast_layer
		space_states.append(sbody.get_world_3d().direct_space_state)

	# Create a 2D Mask for segment to reduce 3D raycasts
	var curve: Curve3D = segment.curve
	var boundingCurve: Curve2D = curve_3d_to_2d(curve)
	var start_width: float = get_road_width(segment.start_point)
	var end_width: float = get_road_width(segment.end_point)
	var bounding_box_offset = Vector2(segment.start_point.global_position.x, segment.start_point.global_position.z)
	var bounding_polygon: PackedVector2Array = curve_2d_to_boundingbox(boundingCurve,start_width,end_width, bounding_box_offset)
	
	var vertex_spacing: float = terrain.vertex_spacing

	# Get global bounding box from mesh, expanded by affected smoothing radius
	var offsets := Vector3(buffer, 0, buffer)
	var aabb: AABB = segment.road_mesh.global_transform * segment.road_mesh.get_aabb()
	var aabb_min := aabb.position - offsets
	var aabb_max := aabb.position + aabb.size + offsets

	# Snap bounds to terrain grid
	var min := Vector3(aabb_min.x, 0, aabb_min.z).snapped(Vector3(vertex_spacing, 0, vertex_spacing))
	var max := Vector3(aabb_max.x, 0, aabb_max.z).snapped(Vector3(vertex_spacing, 0, vertex_spacing)) + Vector3(vertex_spacing, 0, vertex_spacing)

	# Cache the raycasts for missed hits to reduce the number of raycasts
	var recorded: Dictionary = {} # 4.4 typing: Dictionary[Vector2,float]
	var missed: Dictionary = {} # 4.4 typing: Dictionary[Vector2, bool]
	
	# iterate over the xz plane of the curve
	var x = min.x
	while x <= max.x:
		var z = min.z
		while z <= max.z:
			if not Geometry2D.is_point_in_polygon(Vector2(x,z), bounding_polygon):
				z+= vertex_spacing
				continue
			
			# create raycast to check the height at the (x,z) coords
			var height := get_road_height(x,z,aabb_min.y,aabb_max.y,space_states)
			if height.size() > 0:
				set_height_if_active_region(Vector3(x, height[0], z), height[0] + offset)
				recorded[Vector2(x,z)] = height[0]
			else:
				missed[Vector2(x,z)] = true
				#print("Missed: ", Vector2(x,z))
			z += vertex_spacing
		x += vertex_spacing

	var neighbour_range:float = vertex_spacing * 10
	for _m in missed:
		var heights: Array[float] = []
		var neighbour = Vector2(_m.x+neighbour_range,_m.y)
		if recorded.has(neighbour): heights.append(recorded[neighbour])
		neighbour = Vector2(_m.x-neighbour_range,_m.y)
		if recorded.has(neighbour): heights.append(recorded[neighbour])
		neighbour = Vector2(_m.x,_m.y+neighbour_range)
		if recorded.has(neighbour): heights.append(recorded[neighbour])
		neighbour = Vector2(_m.x,_m.y-neighbour_range)
		if recorded.has(neighbour): heights.append(recorded[neighbour])
		if heights.size() > 0:
			set_height_if_active_region(Vector3(_m.x, heights.min(), _m.y), heights[0] + offset)

	for _itemset in revert_layers:
		var sbody: StaticBody3D = _itemset[0]
		sbody.collision_layer = _itemset[1]
		sbody.collision_mask = _itemset[1]


## Returns the distance from a 2D point to a line segment (XZ plane).
func _distance_point_to_segment_2d(p: Vector2, a: Vector2, b: Vector2) -> float:
	var v := b - a
	var u := p - a
	var v_len_sq := v.length_squared()
	if is_zero_approx(v_len_sq):
		return p.distance_to(a)
	var t := clampf(u.dot(v) / v_len_sq, 0.0, 1.0)
	var closest := a + t * v
	return p.distance_to(closest)


## Returns the minimum distance from a 2D point to any edge of the polygon.
## Used for points outside the polygon to compute margin/falloff.
func _distance_to_polygon_boundary_2d(point: Vector2, polygon: PackedVector2Array) -> float:
	if polygon.size() < 2:
		return INF
	var min_dist := INF
	for i in range(polygon.size()):
		var a := polygon[i]
		var b := polygon[(i + 1) % polygon.size()]
		var d := _distance_point_to_segment_2d(point, a, b)
		if d < min_dist:
			min_dist = d
	return min_dist


func _flatten_curve(curve: Curve3D, normalization_value: float):
	if is_zero_approx(normalization_value):
		push_error("Division by zero imminent, curve flattening aborted")
		return
		
	for i in range(curve.point_count):
		var pos:Vector3 = curve.get_point_position(i)
		var pos_in:Vector3 = curve.get_point_in(i)
		var pos_out:Vector3 = curve.get_point_out(i)
		
		# Instead of setting pos.y to 0 we divide it by a large enough value so that it becomes effectively flat
		# This is necessary so we can retrieve the height at a later point. 
		pos.y /= normalization_value 
		pos_in.y /= normalization_value 
		pos_out.y /= normalization_value 
		
		curve.set_point_position(i,pos)
		curve.set_point_in(i,pos_in)
		curve.set_point_out(i,pos_out)


func flatten_terrain_via_intersection(inter: RoadIntersection) -> void:
	if not is_instance_valid(inter):
		return
	if not inter.settings is IntersectionNGon:
		push_warning("Intersection flattening only supported for IntersectionNGon. Skipping.")
		return
	if not inter.edge_points.size():
		push_warning("Intersection has no edge points. Skipping terrain flatten.")
		return

	var center_global: Vector3 = inter.global_position
	var center_y: float = center_global.y + offset
	var vertex_spacing: float = terrain.vertex_spacing

	# Build triangle-fan boundary in world space: [side_l_0, side_r_0, side_l_1, side_r_1, ...]
	# This relies on the fact that edge_points should already be in a clockwise order
	var boundary_world: PackedVector2Array = PackedVector2Array()
	var edge_heights: Array[float] = [center_y]
	for edge in inter.edge_points:
		if not is_instance_valid(edge):
			continue
		var width: float = get_road_width(edge)
		var perp: Vector3 = edge.global_transform.basis.x.normalized()
		
		# TODO: Account for alignment offset once intersections do as well.
		var side_l: Vector3 = edge.global_position - perp * (width * 0.5)
		var side_r: Vector3 = edge.global_position + perp * (width * 0.5)
		if edge.get_prior_road_node(true) == inter:
			# Must insert in the clockwise order, so depends on RP orientation
			var tmp: Vector3 = side_l
			side_l = side_r
			side_r = tmp

		boundary_world.append(Vector2(side_l.x, side_l.z))
		boundary_world.append(Vector2(side_r.x, side_r.z))
		edge_heights.append(edge.global_position.y + offset)
	
	# Simplification for now to just use the lowest y-height amongst all points
	var min_height:float = edge_heights.min()
	if boundary_world.size() < 3:
		return

	# AABB from center and all boundary points, expanded by margin + falloff
	var aabb_min := center_global
	var aabb_max := center_global
	for i in range(boundary_world.size()):
		var v := Vector3(boundary_world[i].x, center_global.y, boundary_world[i].y)
		aabb_min = aabb_min.min(v)
		aabb_max = aabb_max.max(v)
	var offsets := Vector3(edge_margin + edge_falloff, 0.0, edge_margin + edge_falloff)
	aabb_min -= offsets
	aabb_max += offsets

	var min_xz := Vector3(aabb_min.x, 0.0, aabb_min.z).snapped(Vector3(vertex_spacing, 0.0, vertex_spacing))
	var max_xz := Vector3(aabb_max.x, 0.0, aabb_max.z).snapped(Vector3(vertex_spacing, 0.0, vertex_spacing)) + Vector3(vertex_spacing, 0.0, vertex_spacing)

	var x := min_xz.x
	while x <= max_xz.x:
		var z := min_xz.z
		while z <= max_xz.z:
			var pt_2d := Vector2(x, z)

			# TODO: Improve by finding the edge which this point is pointing towards,
			# interpolating the cloesting matching point along that edge,
			# then interpolate along to the center.
			# Instead, for now, we'll just pick the lowest point between them all
			var road_y: float = min_height

			var inside: bool = Geometry2D.is_point_in_polygon(pt_2d, boundary_world)
			var dist_to_boundary: float
			if inside:
				dist_to_boundary = 0.0
			else:
				dist_to_boundary = _distance_to_polygon_boundary_2d(pt_2d, boundary_world)

			if dist_to_boundary <= edge_margin:
				var terrain_pos := Vector3(x, road_y, z)
				set_height_if_active_region(terrain_pos, road_y)
			elif dist_to_boundary <= edge_margin + edge_falloff:
				var terrain_pos := Vector3(x, road_y, z)
				var reference_height: float = get_height_if_active_region(terrain_pos)
				var factor: float = (dist_to_boundary - edge_margin) / edge_falloff
				var smoothed_height: float = _lerp_smoothed_height(road_y, reference_height, factor)
				set_height_if_active_region(terrain_pos, smoothed_height)

			z += vertex_spacing
		x += vertex_spacing


## Called after intersection flattening has completed, to avoid overlap
func intersection_adjacent_segments(inter: RoadIntersection) -> Array:
	var segs: Array = []
	for _edge in inter.edge_points:
		var rp: RoadPoint = _edge as RoadPoint
		if rp.prior_seg:
			segs.append(rp.prior_seg)
		if rp.next_seg:
			segs.append(rp.next_seg)
	return segs


## Approximate method, will have issues with tilting
func flatten_terrain_via_roadsegment_approx(segment: RoadSegment) -> void:
	if not validate_segment(segment):
		return
	var mesh := segment.road_mesh.mesh
	if mesh == null:
		return

	var curve: Curve3D = segment.curve
	var start_width: float = get_road_width(segment.start_point)
	var end_width: float = get_road_width(segment.end_point)
	var vertex_spacing: float = terrain.vertex_spacing
	
	# Creat the flattened version of the curve. 
	# Check out the following Issue for more information why this is necessary: https://github.com/TheDuckCow/godot-road-generator/issues/322
	var flattened_curve: Curve3D = curve.duplicate(true)
	# The normalization factor is picked arbitrary here. The steeper the road, the bigger this value needs to be
	# Values that are too big can cause issues because of float accuracy, too small causes the terrain height to be wrong
	var normalization_factor:float = 10000
	_flatten_curve(flattened_curve,normalization_factor)
	
	# Get global bounding box from mesh, expanded by affected smoothing radius
	var offsets := Vector3(edge_margin+edge_falloff, 0, edge_margin+edge_falloff)
	var aabb: AABB = segment.road_mesh.global_transform * segment.road_mesh.get_aabb()
	var aabb_min := aabb.position - offsets
	var aabb_max := aabb.position + aabb.size + offsets

	# Snap bounds to terrain grid
	var min := Vector3(aabb_min.x, 0, aabb_min.z).snapped(Vector3(vertex_spacing, 0, vertex_spacing))
	var max := Vector3(aabb_max.x, 0, aabb_max.z).snapped(Vector3(vertex_spacing, 0, vertex_spacing)) + Vector3(vertex_spacing, 0, vertex_spacing)

	var world_to_local := segment.global_transform.inverse()

	var x = min.x
	while x <= max.x:
		var z = min.z
		while z <= max.z:
			var world_pos := Vector3(x, 0.0, z)
			var local_pos := world_to_local * world_pos

			var closest_distance := flattened_curve.get_closest_offset(local_pos)
			var curve_point := flattened_curve.sample_baked(closest_distance)
			curve_point.y *= normalization_factor
			var world_curve_point := segment.global_transform * curve_point

			# Check if we are beyond the egde of this RoadSegment, and thus
			# would overlap with updates done by the next RoadSegment
			if closest_distance == 0.0:
				var _offset = world_pos - segment.start_point.global_position 
				var zdist := absf(segment.start_point.global_transform.basis.z.dot(_offset))
				if zdist > vertex_spacing:
					z += vertex_spacing
					continue
			if closest_distance == flattened_curve.get_baked_length():
				var _offset = world_pos - segment.end_point.global_position # check this, also if can be flipped..???
				var zdist:float = abs(segment.end_point.global_transform.basis.z.dot(_offset))
				if zdist > vertex_spacing:
					z += vertex_spacing
					continue

			var sample_position := clampf(closest_distance / flattened_curve.get_baked_length(), 0.0, 1.0)
			var lateral_basis: Vector3 = segment.global_transform.basis * segment._normal_for_offset(segment.curve, sample_position)
			var lateral_basis_horizontal := Vector2(lateral_basis.x, lateral_basis.z)
			var lateral_basis_horizontal_length_squared := lateral_basis_horizontal.length_squared()
			if is_zero_approx(lateral_basis_horizontal_length_squared):
				z += vertex_spacing
				continue
			var lateral_offset := Vector2(x - world_curve_point.x, z - world_curve_point.z).dot(lateral_basis_horizontal) / lateral_basis_horizontal_length_squared
			# Note: this will not be exact as it's not actually linear, as there
			# is some ease/smoothing done for lane count / width changes
			# TODO: Need to account for RoadPoint alignment, right now assumes CENTERED
			# Offset by lane_width * number rev lanes if not centered.
			var width := lerpf(start_width, end_width, sample_position)
			var road_lateral_offset := clampf(lateral_offset, -width * 0.5, width * 0.5)
			var road_y := world_curve_point.y + lateral_basis.y * road_lateral_offset + offset
			var gutter_width := lerpf(segment.start_point.gutter_profile.x, segment.end_point.gutter_profile.x, sample_position)
			if gutter_width > 0.0:
				var paved_half_width := (width - gutter_width * 2.0) * 0.5
				var gutter_factor := clampf((absf(road_lateral_offset) - paved_half_width) / gutter_width, 0.0, 1.0)
				var top_normal: Vector3 = segment.global_transform.basis * segment._top_side_normal_for_offset_eased(segment.curve, sample_position)
				var gutter_depth := lerpf(segment.start_point.gutter_profile.y, segment.end_point.gutter_profile.y, sample_position)
				road_y += top_normal.y * gutter_depth * gutter_factor

			var lat_dist := absf(lateral_offset)
			if lat_dist <= width / 2.0 + edge_margin:
				# Flatten to exactly match the road, adding shoulder margin
				var terrain_pos := Vector3(x, road_y, z)
				set_height_if_active_region(terrain_pos, road_y)
			elif lat_dist <= width / 2.0 + edge_margin + edge_falloff:
				# Smoothly interpolate height beyond shoulder to prior height
				# TODO: improve possible creasing issues caused here
				var terrain_pos := Vector3(x, road_y, z)
				var reference_height:float = get_height_if_active_region(terrain_pos)
				var factor: float = (lat_dist - edge_margin - width / 2.0) / edge_falloff
				var smoothed_height := _lerp_smoothed_height(road_y, reference_height, factor)
				set_height_if_active_region(terrain_pos, smoothed_height)


			z += vertex_spacing
		x += vertex_spacing


func cull_terrain_via_roadsegment(segment: RoadSegment) -> void:
	if not validate_segment(segment):
		print_debug("not valid for culling")
		return

	var mesh := segment.road_mesh.mesh
	if mesh == null:
		print_debug("no mesh found for road, won't cut")
		return
	
	# clean up any lingering collision meshes
	for ch in segment.road_mesh.get_children():
		ch.queue_free()  # Prior collision meshes
	
	# create new colission mesh for eventual raycasting
	print_debug("creating trimesh for hole culling")
	segment.road_mesh.create_trimesh_collision()
	var space_states: Array[PhysicsDirectSpaceState3D] = []
	for ch in segment.road_mesh.get_children():
		var sbody := ch as StaticBody3D # Set to null if casting fails
		if not sbody:
			continue
		sbody.collision_layer = raycast_layer
		sbody.collision_mask = raycast_layer
		space_states.append(sbody.get_world_3d().direct_space_state)
	
	# Create a 2D Mask for segment to reduce 3D raycasts	
	var curve: Curve3D = segment.curve
	var boundingCurve: Curve2D = curve_3d_to_2d(curve)
	var start_width: float = get_road_width(segment.start_point)
	var end_width: float = get_road_width(segment.end_point)
	var bounding_box_offset = Vector2(segment.start_point.global_position.x,segment.start_point.global_position.z)
	var bounding_polygon: PackedVector2Array = curve_2d_to_boundingbox(boundingCurve,start_width,end_width, bounding_box_offset)
	
	var vertex_spacing: float = terrain.vertex_spacing

	# Get global bounding box from mesh, expanded by affected smoothing radius
	var offsets := Vector3(edge_margin+edge_falloff, 0, edge_margin+edge_falloff)
	var aabb: AABB = segment.road_mesh.global_transform * segment.road_mesh.get_aabb()
	var aabb_min := aabb.position - offsets
	var aabb_max := aabb.position + aabb.size + offsets

	# Snap bounds to terrain grid
	var min := Vector3(aabb_min.x, 0, aabb_min.z).snapped(Vector3(vertex_spacing, 0, vertex_spacing))
	var max := Vector3(aabb_max.x, 0, aabb_max.z).snapped(Vector3(vertex_spacing, 0, vertex_spacing)) + Vector3(vertex_spacing, 0, vertex_spacing)

	# hashset for xz plane where the road overlaps the Terrain
	var intersect_coords: Dictionary # 4.4 typing: Dictionary[Vector2,bool]
	
	# itterate over the xz plane of the curve to find intersecting points which are hidden
	var x = min.x
	while x <= max.x:
		var z = min.z
		while z <= max.z:
			# ignore the coords outside of the bounding polygon
			if not Geometry2D.is_point_in_polygon(Vector2(x,z), bounding_polygon):
				z+= vertex_spacing
				continue
			# check that the road does infact cover the terrain on (x,z)
			if get_road_height(x,z,aabb_min.y,aabb_max.y,space_states).size() > 0:
				intersect_coords[Vector2(x,z)] = true
			z += vertex_spacing
		x += vertex_spacing
		
	# free the temporary collision meshs we created
	for ch in segment.road_mesh.get_children():
		ch.queue_free()
	
	#print(str(intersect_coords.keys()))
	# add hole for each point which has all 8 neighbours on x-z plane
	for point in intersect_coords.keys():
		if not terrain.data.has_regionp(Vector3(point.x, 0, point.y)):
			continue
		if intersect_coords.has(Vector2(point.x - vertex_spacing,point.y)) \
		and intersect_coords.has(Vector2(point.x + vertex_spacing,point.y)) \
		and intersect_coords.has(Vector2(point.x,point.y - vertex_spacing)) \
		and intersect_coords.has(Vector2(point.x,point.y + vertex_spacing)) \
		and intersect_coords.has(Vector2(point.x - vertex_spacing,point.y - vertex_spacing)) \
		and intersect_coords.has(Vector2(point.x + vertex_spacing,point.y + vertex_spacing)) \
		and intersect_coords.has(Vector2(point.x + vertex_spacing,point.y - vertex_spacing)) \
		and intersect_coords.has(Vector2(point.x - vertex_spacing,point.y + vertex_spacing)): 
			terrain.data.set_control_hole(Vector3(point.x, 0, point.y), true)


# ------------------------------------------------------------------------------
#endregion
#region Undo/redo
# ------------------------------------------------------------------------------


## The editor's undo history for this scene, or null outside the editor
func _get_editor_history() -> UndoRedo:
	if not Engine.is_editor_hint() or not Engine.has_singleton("EditorInterface"):
		return null
	# By name, as EditorInterface isn't available in exported games
	var undo_redo: Object = Engine.get_singleton("EditorInterface").get_editor_undo_redo()
	return undo_redo.get_history_undo_redo(undo_redo.get_object_history_id(self))


## True if the current road update comes from an undo or redo
func _is_undo_redo_update(history: UndoRedo) -> bool:
	if history.has_redo():
		return true
	return (
		history.get_version() == _undoredo_restored_version
		and Time.get_ticks_msec() - _undoredo_restored_msec < UNDO_RESTORED_WINDOW_MSEC
	)


## Opens an undo action merged into the one that changed the road. Called before
## flattening, as Godot only merges within 800ms and long roads can take longer
func _open_merged_terrain_undo(history: UndoRedo) -> bool:
	if history.get_current_action() < 0:
		return false
	var undo_redo: Object = Engine.get_singleton("EditorInterface").get_editor_undo_redo()
	var action_name := history.get_action_name(history.get_current_action())
	undo_redo.create_action(action_name, UndoRedo.MERGE_ALL, self)
	return true


## Adds the terrain change to the merged action if open, else to its own action
func _add_terrain_undo(heights_before: Dictionary, merged_action_open: bool) -> void:
	var heights_after := _copy_height_maps(heights_before.keys())
	for location in heights_before.keys():
		if heights_before[location].get_data() == heights_after[location].get_data():
			heights_before.erase(location)
			heights_after.erase(location)
	var undo_redo: Object = Engine.get_singleton("EditorInterface").get_editor_undo_redo()
	if not merged_action_open:
		if heights_before.is_empty():
			return
		undo_redo.create_action("Flatten terrain under roads", UndoRedo.MERGE_DISABLE, self)
	if not heights_before.is_empty():
		undo_redo.add_do_method(self, "_set_height_maps", heights_after)
		undo_redo.add_undo_method(self, "_set_height_maps", heights_before)
	undo_redo.commit_action(false)


## Locations of the terrain regions that flattening mesh_parents may change
func _get_regions_reached(mesh_parents: Array) -> Array[Vector2i]:
	var nodes: Array = []
	for _parent in mesh_parents:
		if not is_instance_valid(_parent):
			continue
		nodes.append(_parent)
		if _parent is RoadIntersection:
			nodes.append_array(intersection_adjacent_segments(_parent))
			nodes.append_array(_parent.edge_points)
	var bounds := AABB()
	var has_bounds := false
	for _node in nodes:
		if not is_instance_valid(_node) or not _node is Node3D:
			continue
		var node_bounds := AABB(_node.global_position, Vector3.ZERO)
		var meshes: Array = _node.find_children("*", "MeshInstance3D", true, false)
		if _node is RoadSegment and is_instance_valid(_node.road_mesh):
			meshes.append(_node.road_mesh)
		for _mesh in meshes:
			node_bounds = node_bounds.merge(_mesh.global_transform * _mesh.get_aabb())
		bounds = bounds.merge(node_bounds) if has_bounds else node_bounds
		has_bounds = true
	var locations: Array[Vector2i] = []
	if not has_bounds:
		return locations
	bounds = bounds.grow(edge_margin + edge_falloff + UNDO_BOUNDS_MARGIN)
	var first: Vector2i = terrain.data.get_region_location(bounds.position)
	var last: Vector2i = terrain.data.get_region_location(bounds.end)
	for x in range(first.x, last.x + 1):
		for y in range(first.y, last.y + 1):
			if terrain.data.has_region(Vector2i(x, y)):
				locations.append(Vector2i(x, y))
	return locations


## Copies of the height maps of the given regions, by region location
func _copy_height_maps(locations: Array) -> Dictionary:
	var maps := {}
	for location in locations:
		var region: Object = terrain.data.get_region(location)
		if region:
			maps[location] = region.get_height_map().duplicate()
	return maps


## Undo/redo method to restore height maps
func _set_height_maps(maps: Dictionary) -> void:
	if not is_instance_valid(terrain) or not terrain.data:
		return
	for location in maps.keys():
		var region: Object = terrain.data.get_region(location)
		if not region:
			continue
		# Copy, as later edits modify the region's image in place
		region.set_height_map(maps[location].duplicate())
		region.calc_height_range()
		region.set_modified(true)
	terrain.data.update_maps(TERRAIN_3D_MAPTYPE_HEIGHT)
	terrain.data.calc_height_range()
	_remember_restored_version.call_deferred()


func _remember_restored_version() -> void:
	var history := _get_editor_history()
	if history:
		_undoredo_restored_version = history.get_version()
		_undoredo_restored_msec = Time.get_ticks_msec()


# ------------------------------------------------------------------------------
#endregion
#region Helper functions
# ------------------------------------------------------------------------------


func begin_height_map_edit() -> void:
	_height_map_cache.clear()
	_reference_height_map_cache.clear()
	_height_region_cache.clear()
	_modified_height_regions.clear()
	_missing_height_regions.clear()
	_height_map_edit_active = true


func finish_height_map_edit() -> void:
	if not _height_map_edit_active:
		return
	if not _modified_height_regions.is_empty():
		for region_location in _modified_height_regions:
			var region = _modified_height_regions[region_location]
			region.set_map(TERRAIN_3D_MAPTYPE_HEIGHT, _height_map_cache[region_location])
			region.calc_height_range()
			region.set_modified(true)
			region.set_edited(true)
		terrain.data.update_maps(TERRAIN_3D_MAPTYPE_HEIGHT, false)
		for region in _modified_height_regions.values():
			region.set_edited(false)
	_height_map_cache.clear()
	_reference_height_map_cache.clear()
	_height_region_cache.clear()
	_modified_height_regions.clear()
	_missing_height_regions.clear()
	_height_map_edit_active = false


func get_cached_height_map(terrain_pos: Vector3) -> Image:
	var region_location: Vector2i = terrain.data.get_region_location(terrain_pos)
	if _height_map_cache.has(region_location):
		var cached_height_map: Image = _height_map_cache[region_location]
		return cached_height_map
	if _missing_height_regions.has(region_location):
		return null
	if not terrain.data.has_region(region_location):
		_missing_height_regions[region_location] = true
		return null
	var region = terrain.data.get_region(region_location)
	if not region:
		_missing_height_regions[region_location] = true
		return null
	var reference_height_map: Image = region.get_map(TERRAIN_3D_MAPTYPE_HEIGHT)
	if reference_height_map == null:
		_missing_height_regions[region_location] = true
		return null
	var height_map: Image = reference_height_map.duplicate()
	_height_map_cache[region_location] = height_map
	_reference_height_map_cache[region_location] = reference_height_map
	_height_region_cache[region_location] = region
	return height_map


# TODO: Replace with official function once in a release, see:
# https://github.com/TokisanGames/Terrain3D/pull/1049
func get_height_map_pixel(terrain_pos: Vector3) -> Vector2i:
	var vertex_spacing: float = terrain.vertex_spacing
	var region_size: int = terrain.region_size
	var vertex_grid_position: Vector2i = Vector2i(
		floori(terrain_pos.x / vertex_spacing),
		floori(terrain_pos.z / vertex_spacing)
	)
	return Vector2i(
		posmod(vertex_grid_position.x, region_size),
		posmod(vertex_grid_position.y, region_size)
	)


func get_height_if_active_region(terrain_pos: Vector3) -> float:
	if not _height_map_edit_active:
		return terrain.data.get_height(terrain_pos)
	var height_map: Image = get_cached_height_map(terrain_pos)
	if height_map == null:
		return NAN
	var region_location: Vector2i = terrain.data.get_region_location(terrain_pos)
	var reference_height_map: Image = _reference_height_map_cache[region_location]
	return reference_height_map.get_pixelv(get_height_map_pixel(terrain_pos)).r


## Safely sets height for a region, handling if it exists or not
func set_height_if_active_region(terrain_pos: Vector3, height: float) -> void:
	if not _height_map_edit_active:
		if terrain.data.has_regionp(terrain_pos):
			terrain.data.set_height(terrain_pos, height)
		return
	var height_map: Image = get_cached_height_map(terrain_pos)
	if height_map == null:
		return
	var region_location: Vector2i = terrain.data.get_region_location(terrain_pos)
	height_map.set_pixelv(get_height_map_pixel(terrain_pos), Color(height, 0.0, 0.0, 1.0))
	_modified_height_regions[region_location] = _height_region_cache[region_location]


# TODO: Move this utility into the RoadSegment (with offset) or RoadPoint class (no offset)
func get_road_width(point: RoadPoint) -> float:
	return (point.gutter_profile.x*2
		+ point.shoulder_width_l
		+ point.shoulder_width_r
		+ point.lane_width * point.lanes.size()
	)


## Used to create a "Mask" 
func curve_3d_to_2d(curve: Curve3D) -> Curve2D:
	var curve2d := Curve2D.new()
	var point_count := curve.get_point_count()
	
	for i in point_count:
		var pos3 = curve.get_point_position(i)
		var in3 = curve.get_point_in(i)
		var out3 = curve.get_point_out(i)
		var tilt = curve.get_point_tilt(i)

		# Project to XZ plane (drop Y)
		var pos2 = Vector2(pos3.x, pos3.z)
		var in2 = Vector2(in3.x, in3.z)
		var out2 = Vector2(out3.x, out3.z)

		curve2d.add_point(pos2, in2, out2)
	return curve2d


func curve_2d_to_boundingbox(curve: Curve2D, start_width: float, end_width: float, offset: Vector2) -> PackedVector2Array:
	var baked := curve.get_baked_points()
	var count := baked.size()
	var result := PackedVector2Array()
	if count < 2:
		return result

	var left_points: Array[Vector2] = []
	var right_points: Array[Vector2] = []
	
	# first tangent
	var extrapolated_neg_1 = baked[0] - baked[1]
	var tangent: Vector2 = (baked[0] - extrapolated_neg_1).normalized()
	var perpendicular_right = tangent.rotated(deg_to_rad(90))
	var perpendicular_left = tangent.rotated(deg_to_rad(-90))
	left_points.append(extrapolated_neg_1 + perpendicular_left * start_width + offset)
	right_points.append(extrapolated_neg_1 + perpendicular_right * start_width + offset)
		
	for i in count:
		if i == 0:
			tangent = (baked[1] - baked[0]).normalized()
		elif i == count - 1:
			tangent = (baked[i] - baked[i - 1]).normalized()
		else:
			tangent = (baked[i+1] - baked[i-1]).normalized()
		perpendicular_right = tangent.rotated(deg_to_rad(90))
		perpendicular_left = tangent.rotated(deg_to_rad(-90))
		var t := float(i) / float(count - 1)
		var width := lerpf(start_width, end_width, t) * 0.5
		left_points.append(baked[i] + perpendicular_left * width + offset)
		right_points.append(baked[i] + perpendicular_right * width + offset)
		
	var extrapolated_last = baked[count - 1] + (baked[count - 1] - baked[count - 2])
	tangent = (extrapolated_last - baked[count - 1]).normalized()
	perpendicular_right = tangent.rotated(deg_to_rad(90))
	perpendicular_left = tangent.rotated(deg_to_rad(-90))
	left_points.append(extrapolated_last + perpendicular_left * end_width + offset)
	right_points.append(extrapolated_last + perpendicular_right * end_width + offset)
		
	right_points.reverse()
	result.append_array(PackedVector2Array(left_points))
	result.append_array(PackedVector2Array(right_points))
	return result


func validate_segment(segment: RoadSegment) -> bool:
	if not is_instance_valid(segment):
		return false
	if not is_instance_valid(segment.start_point) or not is_instance_valid(segment.end_point):
		return false
	return is_instance_valid(segment.road_mesh)


# can't be nullable so an empty array indicates null (failed to find a height)
func get_road_height(x: float, z: float, min_y: float, max_y: float, space_states: Array[PhysicsDirectSpaceState3D]) -> Array[float]:
	var ray := PhysicsRayQueryParameters3D.create(Vector3(x, max_y, z),Vector3(x, min_y, z))
	ray.collision_mask = raycast_layer
	var set_height := false
	var height:float = 0.0 
	for state in space_states:
		var result = state.intersect_ray(ray)
		if not result.is_empty() and result.has("position"):
			if not set_height: 
				set_height = true
				height = result["position"].y
			else:
				height = max(height, result["position"].y)
	if set_height:
		return [height]
	return []


## Reusable function to perform consistent falloff rate
func _lerp_smoothed_height(road_y: float, terrain_y: float, factor: float) -> float:
	return lerpf(road_y, terrain_y, ease(factor, -1.5))

#endregion
# ------------------------------------------------------------------------------
