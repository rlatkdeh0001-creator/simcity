extends "res://tests/_e4b_d27_a.gd"
## Candidate-only D27 B. A never loads or parses this script.
const Profile = preload("res://core/road_profile.gd")

func scene_name() -> String:
	return "B"

func add_branches(city) -> bool:
	var variants := [Profile.BranchVariant.SIX_METRE, Profile.BranchVariant.EIGHT_METRE]
	var widths := [6.0, 8.0]
	for i in range(2):
		var y: float = [12.0, 85.0][i]
		var points := PackedVector2Array([Vector2(45,y), Vector2(61,y)])
		var result: Dictionary = city.add_branch_one_way(points, variants[i])
		if not result.get("ok",false) or city.roads.size() != 7+i:
			return false
		var road: Dictionary = city.roads.back()
		if absf(Profile.width_for_record(road)*4.0-widths[i]) > 0.001 or int(road.get("lanes",0)) != i+1 or int(road.get("travel_dir",0)) != 1:
			return false
	return true
