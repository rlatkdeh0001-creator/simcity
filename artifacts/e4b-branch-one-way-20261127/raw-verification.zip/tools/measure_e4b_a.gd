extends SceneTree
## E4b D27. This source is copied byte-for-byte into both A projects.
const City = preload("res://core/city_model.gd")
const FRAMEBUFFER := Vector2i(1920, 1080)
const WARM_US := 1000000
const SAMPLE_US := 4000000
var game

func _initialize():
	run.call_deferred()

func settle():
	for i in range(8):
		await process_frame

# Historical capture_perf_cadence fixture: its unrelated capture methods are not inherited.
func fixture():
	var city = City.new(100, 100, 20261114)
	for y in [28, 48, 68]:
		if not city.add_road(PackedVector2Array([Vector2(24,y),Vector2(72,y)])).ok:
			return null
	for x in [28, 48, 68]:
		if not city.add_road(PackedVector2Array([Vector2(x,24),Vector2(x,72)])).ok:
			return null
	for parcel in city.zoning_grid.parcels.values():
		if parcel.v != 0 or parcel.u % 4 != 0:
			continue
		city.add_building_at(parcel.center)
		if city.buildings.size() >= 24:
			break
	return city

func finish(code: int):
	if is_instance_valid(game):
		if game.is_inside_tree():
			game.queue_free()
			await process_frame
		else:
			game.free()
	quit(code)

func require(ok: bool, message: String) -> bool:
	if not ok:
		printerr("FAIL D27 ", message)
	return ok

func scene_name() -> String:
	return "A"

func add_branches(_city) -> bool:
	return false

func layout_fingerprint(include_progress: bool = true) -> String:
	var cars: Array = game.traffic.simulation.vehicles
	var state := [game.city.roads, game.city.buildings, cars.map(func(car): return [car.id, car.get("asset"), car.get("route"), car.get("progress") if include_progress else null]), game.map_zoom, game.origin]
	var digest := HashingContext.new()
	digest.start(HashingContext.HASH_SHA256)
	digest.update(var_to_bytes(state))
	return digest.finish().hex_encode()

func sample_frames(animate: bool) -> Dictionary:
	var warm_until := Time.get_ticks_usec() + WARM_US
	while Time.get_ticks_usec() < warm_until:
		await RenderingServer.frame_post_draw
		if animate:
			game.traffic.update(root.get_process_delta_time())
	var start := Time.get_ticks_usec()
	var previous := start
	var durations: Array[int] = []
	while previous - start < SAMPLE_US:
		await RenderingServer.frame_post_draw
		var now := Time.get_ticks_usec()
		durations.append(now - previous)
		previous = now
		if animate:
			game.traffic.update(root.get_process_delta_time())
	return {"frame_usec": durations, "frames": durations.size(), "elapsed_usec": previous-start}

func run():
	var args := OS.get_cmdline_user_args()
	var method := RenderingServer.get_current_rendering_method()
	var driver := RenderingServer.get_current_rendering_driver_name()
	var scene := scene_name()
	if not require(args.size() == 1 and args[0].begins_with("--frames-json="), "expected one JSON output argument"):
		await finish(1)
		return
	var destination := args[0].trim_prefix("--frames-json=")
	if not require(destination.is_absolute_path() and not FileAccess.file_exists(destination), "expected fresh absolute JSON destination"):
		await finish(1)
		return
	if not require(method == "gl_compatibility" and driver == "opengl3" and DisplayServer.get_name() != "headless" and root.size == FRAMEBUFFER and DisplayServer.window_get_size() == FRAMEBUFFER and root.mode in [Window.MODE_FULLSCREEN, Window.MODE_EXCLUSIVE_FULLSCREEN], "expected native Compatibility/OpenGL3 1920x1080 fullscreen"):
		await finish(1)
		return
	DisplayServer.window_set_vsync_mode(DisplayServer.VSYNC_DISABLED)
	Engine.max_fps = 0
	if not require(DisplayServer.window_get_vsync_mode() == DisplayServer.VSYNC_DISABLED, "VSync was not disabled"):
		await finish(1)
		return
	var city = fixture()
	if not require(city != null and city.roads.size() == 6 and city.buildings.size() == 24, "historical fixture geometry differed"):
		await finish(1)
		return
	var original_roads: Array = city.roads.duplicate(true)
	var original_buildings: Array = city.buildings.duplicate(true)
	if scene == "B" and not require(add_branches(city) and city.roads.size() == 8 and city.roads.slice(0,6) == original_roads and city.buildings == original_buildings, "branch additions must preserve original roads and buildings"):
		await finish(1)
		return
	game = load("res://main.tscn").instantiate()
	if game.city != null and game.city.simulation != null:
		game.city.simulation.shutdown()
	game.city = city
	game.paused = true
	root.add_child(game)
	current_scene = game
	await settle()
	if not require(game.traffic.rebuild(city.roads), "fixture traffic cannot build"):
		await finish(1)
		return
	game.traffic.seed_traffic()
	game.traffic.simulation.paused = true
	var moving: Array[Dictionary] = []
	var held: Array[Dictionary] = []
	var moving_roads := [0, 0]
	for car: Dictionary in game.traffic.simulation.vehicles:
		var lane: Dictionary = game.traffic.network.lanes[car.lane]
		var index: int = lane.road
		if scene == "B" and index in [6,7] and lane.direction == 1:
			car.max_speed = 5.0
			moving.append(car)
			moving_roads[index-6] += 1
		else:
			if scene == "B":
				car.max_speed = 0.0
			held.append(car)
	if not require(held.size() == 24 and (scene == "A" or (moving.size() == 3 and moving_roads == [1,2])), "expected 24 held cars plus one/two directed actors on the 6m/8m branches in B"):
		await finish(1)
		return
	game.mode = "select"
	game.drawer.hide()
	game.map_zoom = .9
	game.origin = Vector2(960,410) - game.world_renderer.iso(Vector2(48,48)) * game.map_zoom
	game.refresh()
	await settle()
	var deadline := Time.get_ticks_msec() + 30000
	while game.building_views.busy or not game.building_views.queue.is_empty():
		if not require(Time.get_ticks_msec() < deadline, "building SubViewports did not settle"):
			await finish(1)
			return
		await process_frame
	var layout := layout_fingerprint(scene == "A")
	if scene == "B":
		game.traffic.simulation.paused = false
	var result := await sample_frames(scene == "B")
	if not require(game.paused and game.traffic.simulation.paused == (scene == "A") and layout == layout_fingerprint(scene == "A"), "fixture, routes or pause state changed"):
		await finish(1)
		return
	if not require(held.all(func(car): return car.distance == 0.0 and car.speed == 0.0), "the original 24 vehicles moved"):
		await finish(1)
		return
	if not require(moving.all(func(car): return car.distance > 1.0 and car.speed > 0.0 and not car.arrived), "the branch vehicles did not move and remain active"):
		await finish(1)
		return
	result.merge({"scene":scene, "method":method, "driver":driver, "layout_sha256":layout,
		"seed":20261114, "roads":city.roads.size(), "buildings":city.buildings.size(),
		"vehicles":game.traffic.simulation.vehicles.size(), "moving_vehicles":moving.size(), "held_vehicles":held.size(),
		"moving_by_branch":moving_roads if scene == "B" else [], "branch_widths_m":[6,8] if scene == "B" else [],
		"width":root.size.x, "height":root.size.y, "fullscreen":true, "vsync":false, "max_fps":Engine.max_fps,
		"paused":true, "warmup_usec":WARM_US, "sample_min_usec":SAMPLE_US, "zoom":game.map_zoom,
		"camera_world_cell":[48,48], "camera_screen_point":[960,410]})
	var output := FileAccess.open(destination, FileAccess.WRITE)
	if not require(output != null, "cannot open raw frames JSON"):
		await finish(1)
		return
	var written := output.store_string(JSON.stringify(result, "  "))
	output.close()
	if not require(written, "cannot write raw frames JSON"):
		await finish(1)
		return
	print("D27_PASS E4b scene=", scene, " method=", method, " driver=", driver)
	await finish(0)
