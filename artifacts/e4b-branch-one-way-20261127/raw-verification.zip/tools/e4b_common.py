"""Read-only Git input, isolated snapshot preparation and bounded wrapper calls."""
import argparse
from contextlib import contextmanager
import csv
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import re
import shutil
import stat
import subprocess
import sys
import tarfile
import tempfile

HERE = Path(__file__).resolve().parent
ROOT = Path('D:/project/simcity')
BRANCH = 'feature/e4-one-way-roads'
BASE = '85ded3e35023b7404df4e219598335f088bef7bc'
WRAPPER_HASH = '6415e919ae67d26c3dcbf62700037393853b3b0213c09be44bcd94c7056568f7'
ENV_HASH = 'dfda871a7044bf5304c4af23267e9ecef84ad6bad9f08e87158220e0bc00194f'
SDK = Path('D:/tools/dotnet')
GODOT = Path('D:/tools/godot-dotnet')
BASE_FIXTURE = 'tests/_e4b_d27_a.gd'
BRANCH_FIXTURE = 'tests/_e4b_d27_b.gd'
CACHE = ('.godot/imported', '.godot/global_script_class_cache.cfg', '.godot/uid_cache.bin', '.godot/mono/temp/bin/Debug')
DLL = CACHE[-1] + '/CitiesDo.dll'
FATAL = re.compile(r'^\s*(?:SCRIPT ERROR\b|ERROR\b|FAIL\b|FATAL\b|CRASH\b|Owned toolchain process exceeded|Traceback\b)|0xC0000005|ObjectDB.*(?:leak|in use)|resources? still in use|threads? (?:has|have) not been disposed', re.I)
WARNING = re.compile(r'^\s*WARNING\b', re.I)


def require(ok, message):
    if not ok:
        raise ValueError(message)


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def json_read(path):
    return json.loads(path.read_bytes())


def json_new(path, data):
    with path.open('x', encoding='utf-8', newline='\n') as stream:
        json.dump(data, stream, ensure_ascii=False, indent=2, allow_nan=False)
        stream.write('\n')


def git(*args):
    return subprocess.check_output(['git', '--no-optional-locks', '-C', str(ROOT), *args], cwd=HERE)


def checkout_gate():
    require(git('rev-parse', 'HEAD').decode().strip() == BASE, 'HEAD is not the pinned post-B E4b start')
    require(git('branch', '--show-current').decode().strip() == BRANCH, 'unexpected branch')
    require(not git('diff', '--cached', '--name-only', '-z'), 'index is not empty')


def blob(path):
    return git('show', f'{BASE}:{path}')


def relative(text):
    p = PurePosixPath(text)
    require(text and p.as_posix() == text and not p.is_absolute()
            and all(part not in ('.','..') and part.rstrip(' .') == part for part in p.parts)
            and all(ch not in text for ch in '\\:*?"<>|\0'), f'unsafe relative path: {text!r}')
    return p


def ordinary(path):
    try:
        return not (getattr(path.lstat(), 'st_file_attributes', 0) & stat.FILE_ATTRIBUTE_REPARSE_POINT) and not path.is_symlink()
    except FileNotFoundError:
        return False


def checked(root, rel):
    path = root
    for part in relative(rel).parts:
        path = path / part
        require(ordinary(path), f'missing input or reparse point: {path}')
    return path


def scratch(path):
    path = path.absolute()
    resolved = path.resolve()
    require(path == resolved and resolved.is_relative_to(HERE) and resolved != HERE,
            f'path must be a direct, non-aliased descendant of {HERE}: {path}')
    return resolved


def entry_chain(root, name, seen=()):
    require(name not in seen, f'circular script inheritance: {name}')
    source = checked(root, name).read_text(encoding='utf-8-sig')
    match = re.search(r'^extends\s+(?:"([^"\r\n]+)"|(\w+))', source, re.M)
    require(match, f'no top-level extends: {name}')
    if match[2]:
        require(match[2] in ('SceneTree', 'MainLoop'), f'not a standalone entry: {name}')
        return (*seen, name)
    base = match[1]
    target = base[6:] if base.startswith('res://') else (PurePosixPath(name).parent / relative(base)).as_posix()
    return entry_chain(root, target, (*seen, name))


def tree(root, *, filter_project=False):
    result = {}
    for folder, dirs, files in os.walk(root, onerror=lambda err: (_ for _ in ()).throw(err)):
        parent = Path(folder)
        for name in [*dirs, *files]:
            require(ordinary(parent / name), f'reparse point in inputs: {parent / name}')
        if filter_project and parent == root:
            dirs[:] = [d for d in dirs if d != '.godot']
        for name in files:
            path = parent / name
            result[path.relative_to(root).as_posix()] = sha(path)
    return dict(sorted(result.items()))


def project_pin(project):
    result = tree(project, filter_project=True)
    for rel in CACHE:
        path = checked(project, rel)
        if path.is_dir():
            result.update({f'{rel}/{k}': v for k, v in tree(path).items()})
        else:
            result[rel] = sha(path)
    require(DLL in result and 'project.godot' in result, 'prepared managed DLL/project settings missing')
    return result


def runtime_pin():
    consoles = list(GODOT.rglob('Godot_v4.6.3-stable_mono_win64_console.exe'))
    require(len(consoles) == 1, f'expected exactly one approved Godot console exe: {consoles}')
    editor = consoles[0].with_name(consoles[0].name.replace('_console.exe', '.exe'))
    files = [*consoles, editor, SDK/'dotnet.exe', *sorted(SDK.glob('host/fxr/*/hostfxr.dll'))]
    require(len(files) >= 4, 'approved .NET hostfxr missing')
    managed = consoles[0].parent / 'GodotSharp/Api/Debug'
    shared = sorted((SDK/'shared/Microsoft.NETCore.App').glob('*/coreclr.dll'))
    require(shared and managed.is_dir(), 'approved .NET runtime or GodotSharp Debug API missing')
    # Pin the runtime distribution files, but not unrelated SDK caches or user settings.
    files += [p for p in managed.rglob('*') if p.is_file()]
    for core in shared:
        files += [p for p in core.parent.iterdir() if p.is_file()]
    return {p.as_posix(): sha(p) for p in sorted(set(files))}


def wrapper_inputs():
    wrapper, env = map(blob, ('tools/run_dotnet.py','tools/dotnet_env.py'))
    require((digest(wrapper), digest(env)) == (WRAPPER_HASH, ENV_HASH), 'wrapper or environment blob changed')
    # Retain the approved executable/SDK discovery. Redirect writable caches only.
    anchor = b"GODOT = ROOT / 'godot-dotnet'"
    require(env.count(anchor) == 1, 'unexpected Godot environment anchor')
    env = env.replace(anchor, anchor + b"\nSTATE = Path(__file__).resolve().parents[1] / 'runtime-state'")
    start, tail = env.split(b'def environment():', 1)
    return {'run_dotnet.py': wrapper, 'dotnet_env.py': start + b'def environment():' + tail.replace(b'ROOT / ', b'STATE / ')}


def overlay_input(text):
    p = relative(text)
    require(p.parts[0] in ('core', 'tests') or text in ('main.gd', 'bottom_ui.gd'), f'not an E4b source overlay: {text}')
    require(p.suffix == '.gd' and not any(part.startswith('.') for part in p.parts)
            and text not in (BASE_FIXTURE, BRANCH_FIXTURE), f'not a .gd feature/test overlay: {text}')
    return checked(ROOT/'cities_do', text).read_bytes()


def archive_project(target):
    # Git blobs only (there are no source overrides in baseline). Stream to avoid
    # buffering the entire asset tree. Reject Git symlinks/special files.
    with subprocess.Popen(['git','--no-optional-locks','-C',str(ROOT),'archive','--format=tar',BASE,'cities_do'],
                          stdout=subprocess.PIPE, cwd=HERE) as proc:
        with tarfile.open(fileobj=proc.stdout, mode='r|') as archive:
            for member in archive:
                path = target / relative(member.name)
                require(path.is_relative_to(target/'cities_do'), f'unexpected archive member: {member.name}')
                if member.isdir():
                    path.mkdir(parents=True, exist_ok=True)
                elif member.isfile():
                    path.parent.mkdir(parents=True, exist_ok=True)
                    with archive.extractfile(member) as src, path.open('xb') as dst:
                        shutil.copyfileobj(src, dst)
                else:
                    raise ValueError(f'unsupported archive member: {member.name}')
        require(proc.wait() == 0, 'git archive failed')


def copy_import_sidecars(source, target):
    # The artifact cache is not a remap table. Preserve only existing remaps
    # for identical tracked assets, and only when their cached outputs exist.
    copied = 0
    checkout_eol = 0
    for asset in sorted((target/'assets').rglob('*')):
        if not asset.is_file() or asset.suffix == '.import':
            continue
        logical = asset.relative_to(target).as_posix()
        sidecar = source/(logical+'.import')
        dest = target/(logical+'.import')
        if dest.exists() or not sidecar.is_file():
            continue
        require(ordinary(sidecar), f'unsafe asset remap: {sidecar}')
        raw = sidecar.read_bytes()
        if f'source_file="res://{logical}"'.encode() not in raw:
            continue
        outputs = {p.decode('utf-8') for p in re.findall(rb'"res://(\.godot/imported/[^"\r\n]+)"', raw)}
        if not outputs or not all((target/relative(p)).is_file() for p in outputs):
            continue
        local = checked(source, logical).read_bytes()
        archived = asset.read_bytes()
        if local != archived:
            # git archive can apply checkout EOL conversion to a text source.
            # Restore the byte form used by the cached import only in scratch.
            if asset.suffix.lower() not in ('.svg', '.obj', '.ttf', '.csv') or b'\0' in local or b'\0' in archived:
                continue
            if local.replace(b'\r\n', b'\n') != archived.replace(b'\r\n', b'\n'):
                continue
            asset.write_bytes(local)
            checkout_eol += 1
        with dest.open('xb') as stream:
            stream.write(raw)
        require(sha(sidecar) == sha(dest) and sha(source/logical) == sha(asset), f'asset/remap changed during copy: {logical}')
        copied += 1
    required = target/'assets/ui/currency-icon-A.svg.import'
    require(required.is_file(), 'known preload lacks a pinned remap and cached texture')
    print(f'Copied {copied} remaps for byte-matching assets and cache outputs ({checkout_eol} EOL-only archive forms)', flush=True)


def prepare(out, overlays):
    checkout_gate()
    require(len(set(overlays)) == len(overlays), 'duplicate overlay')
    sources = {name: overlay_input(name) for name in overlays}
    runtime = runtime_pin()
    base, cand = (out/v/'cities_do' for v in ('baseline','candidate'))
    out.mkdir(exist_ok=False)
    archive_project(base.parent)
    source_project = ROOT/'cities_do'
    cache_before = {}
    for name in CACHE:
        src = checked(source_project, name)
        dst = base / name
        dst.parent.mkdir(parents=True, exist_ok=True)
        cache_before[name] = tree(src) if src.is_dir() else sha(src)
        if src.is_dir():
            shutil.copytree(src, dst)
        else:
            shutil.copyfile(src, dst)
        observed = lambda p: tree(p) if p.is_dir() else sha(p)
        require(observed(src) == cache_before[name] == observed(dst), f'cache changed while copying: {name}')
    copy_import_sidecars(source_project, base)
    with (base/BASE_FIXTURE).open('xb') as stream:
        stream.write((HERE/'measure_e4b_a.gd').read_bytes())
    shutil.copytree(base, cand)
    with (cand/BRANCH_FIXTURE).open('xb') as stream:
        stream.write((HERE/'measure_e4b_b.gd').read_bytes())
    for name, raw in sources.items():
        path = cand / name
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(raw)
    tools = out/'tools'
    tools.mkdir()
    wrappers = wrapper_inputs()
    for name, raw in wrappers.items():
        (tools/name).write_bytes(raw)
    pins = {v: project_pin(out/v/'cities_do') for v in ('baseline','candidate')}
    expected = {**pins['baseline'], BRANCH_FIXTURE: sha(HERE/'measure_e4b_b.gd'), **{p: digest(b) for p,b in sources.items()}}
    require(pins['candidate'] == expected, 'unexpected candidate source/cache difference')
    require(pins['baseline'][BASE_FIXTURE] == sha(HERE/'measure_e4b_a.gd'), 'A script changed during preparation')
    checkout_gate()
    require(all(overlay_input(n) == raw for n,raw in sources.items()), 'feature source changed during preparation')
    require(runtime_pin() == runtime, 'toolchain changed during preparation')
    json_new(out/'inputs.json', {'schema':1, 'stage':'E4b', 'baseline':BASE, 'branch':BRANCH,
             'runtime':runtime, 'wrapper_blob_sha256':WRAPPER_HASH, 'env_blob_sha256':ENV_HASH,
             'wrapper':{p: digest(raw) for p,raw in wrappers.items()}, 'projects':pins,
             'overlays':{p:digest(raw) for p,raw in sources.items()}})
    print(out/'inputs.json')


def load_pin(snapshot):
    data = json_read(snapshot/'inputs.json')
    require((data['schema'],data['stage'],data['branch'],data['baseline']) == (1,'E4b',BRANCH,BASE), 'wrong E4b snapshot')
    baseline, candidate = (data['projects'][v] for v in ('baseline','candidate'))
    require(BASE_FIXTURE in baseline and BRANCH_FIXTURE not in baseline and all(
            p not in (*CACHE, BASE_FIXTURE, BRANCH_FIXTURE, 'project.godot') and relative(p).suffix == '.gd' for p in data['overlays']),
            'overlay changes protected inputs')
    require({**baseline, BRANCH_FIXTURE:candidate[BRANCH_FIXTURE], **data['overlays']} == candidate,
            'unexpected candidate project, settings or DLL drift')
    require(data['wrapper'] == {p:digest(raw) for p,raw in wrapper_inputs().items()}, 'wrong wrapper fingerprint')
    return data


def validate(snapshot, pin, *variants, live=False):
    require(json_read(checked(snapshot, 'inputs.json')) == pin, 'snapshot manifest changed')
    require(tree(snapshot/'tools') == pin['wrapper'], 'copied wrapper changed')
    require(all(project_pin(snapshot/v/'cities_do') == pin['projects'][v] for v in variants), 'scratch project/cache changed')
    if live:
        require(runtime_pin() == pin['runtime'], 'engine/.NET fingerprint changed')


def diagnostics(text):
    return [line for line in text.splitlines() if FATAL.search(line) or WARNING.search(line)]


def require_idle():
    raw = subprocess.check_output(['tasklist.exe','/FO','CSV','/NH'], cwd=HERE, timeout=15)
    rows = list(csv.reader(raw.decode('mbcs', errors='replace').splitlines()))
    require(rows and all(len(row) >= 2 and row[1].isdigit() for row in rows), 'tasklist was not verifiable')
    other = [(row[0],row[1]) for row in rows if 'godot' in row[0].casefold() and row[0].lower().endswith('.exe')]
    require(not other, f'exclusive Godot window unavailable: {other}')


@contextmanager
def exclusive():
    lock = HERE/'.engine-lock'
    lock.mkdir(exist_ok=False)
    try:
        require_idle()
        yield
    finally:
        lock.rmdir()


def command(snapshot, variant, timeout, flags):
    return [sys.executable, '-B', str(snapshot/'tools/run_dotnet.py'), '--timeout', str(timeout), 'godot',
            '--path', (snapshot/variant/'cities_do').as_posix(), '--audio-driver', 'Dummy', *flags]


def engine(snapshot, argv, log=None):
    require_idle()
    environment = dict(os.environ)
    # Godot self-contained mode can otherwise derive shared paths from its executable.
    environment['GODOT_USE_SELF_CONTAINED'] = '0'
    if '--headless' not in argv:
        # dotnet_env in this scratch copy sets APPDATA below runtime-state.
        # Keep cold caches symmetric and preserve, rather than delete, prior state.
        relative_cache = 'runtime-state/dotnet-user/AppData/Roaming/Godot/app_userdata/CITIES_DO · Construction Lab/shader_cache'
        cache = snapshot / relative_cache
        if cache.exists():
            cache = checked(snapshot, relative_cache)
            require(cache.is_dir(), f'shader cache is not a normal directory: {cache}')
            prior = Path(tempfile.mkdtemp(prefix='shader-',dir=snapshot))/'shader_cache'
            cache.rename(prior)
            print(f'Preserved scratch GL cache before native launch: {prior}', flush=True)
    if log is None:
        result = subprocess.run(argv, cwd=snapshot, env=environment, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
        text = result.stdout.decode('utf-8', 'replace')
    else:
        with log.open('xb') as stream:
            result = subprocess.run(argv, cwd=snapshot, env=environment, stdout=stream, stderr=subprocess.STDOUT)
        text = log.read_text(encoding='utf-8', errors='replace')
    require_idle()
    return result.returncode, text


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('action', choices=['prepare','check'])
    parser.add_argument('--snapshot', required=True, type=Path)
    parser.add_argument('--overlay', action='append', default=[], metavar='PROJECT_RELATIVE_GD')
    args = parser.parse_args()
    path = scratch(args.snapshot)
    if args.action == 'prepare':
        prepare(path, args.overlay)
    else:
        require(not args.overlay, '--overlay is only for prepare')
        validate(path, load_pin(path), 'baseline','candidate', live=True)
        print('E4b frozen snapshot matches pinned inputs; engine not launched')


def cli(function):
    try:
        raise SystemExit(function())
    except (OSError, ValueError, KeyError, subprocess.SubprocessError) as error:
        raise SystemExit(str(error)) from error


if __name__ == '__main__':
    cli(main)
