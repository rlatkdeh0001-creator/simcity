"""Read-only E4b acceptance manifest: independently recheck evidence and pins."""
import argparse
import json
from pathlib import Path

import e4b_common as c
import measure_e4b_paired as d
import verify_e4b_branch_one_way as f


def suite(snapshot,root,variant,mode,pin,allow):
    directory = c.checked(root, f'{variant}/{mode}')
    report_file = c.checked(directory,'results.json')
    report = c.json_read(report_file)
    names = f.inventory(variant,mode)
    c.require((report['stage'],report['pin_sha256'],report['variant'],report['mode'],report['expected']) ==
              ('E4b',c.sha(snapshot/'inputs.json'),variant,mode,list(names)), 'functional run has wrong stage, pin or scope')
    rows = report['rows']
    c.require(tuple(row['name'] for row in rows) == names and
              {p.name for p in directory.glob('*.log')} == {name+'.log' for name in names}, 'missing/extra/duplicate functional suite')
    project = snapshot/variant/'cities_do'
    for name,row in zip(names,rows):
        path = f'tests/{name}.gd'
        pins = pin['projects'][variant]
        chain = c.entry_chain(project,path)
        script, script_hash = 'res://'+path, pins[path]
        if name == f.ZONING:
            redirect = c.checked(directory,'untimed-test_roads_zoning.gd')
            c.require(redirect.read_bytes() == f.untimed_zoning((project/path).read_bytes()), 'untimed zoning redirect differs')
            script,script_hash = redirect.as_posix(),c.sha(redirect)
        log = c.checked(directory,name+'.log')
        text = log.read_text(encoding='utf-8',errors='replace')
        counts = f.review(name,text,row['exit_code'],f.allowance_for(allow,mode,name))
        flags = (['--headless'] if mode == 'headless' else f.NATIVE_FLAGS[:]) + ['--script',script]
        if mode == 'native-capture':
            flags += ['--',*(f'--e4b-{k}-capture={(directory/v).as_posix()}' for k,v in f.CAPTURES.items())]
        c.require((row['source_sha256'],row['script'],row['script_sha256'],row['entry_sha256'],row['counts'],row['diagnostics'],
                  row['log_sha256'],row['command']) == (pins[path],script,script_hash,{p:pins[p] for p in chain},list(counts),
                  c.diagnostics(text),c.sha(log),c.command(snapshot,variant,240,flags)), f'functional evidence mismatch: {log}')
    captures = f.capture_facts(directory,mode)
    c.require(captures == report['captures'], 'functional capture hashes differ')
    return dict(suite_count=len(names), passing_assertions=sum(r['counts'][0] for r in rows),
                results_sha256=c.sha(report_file), captures=captures)


def performance(snapshot,out):
    summary = c.json_read(c.checked(out,'summary.json'))
    rows = []
    for scene,index,variant in d.schedule(summary['pairs']):
        raw,log,argv = d.make_command(snapshot,out,scene,index,variant)
        for path in (raw,log,log.with_suffix('.exit.json')):
            c.checked(out,path.name)
        status = c.json_read(log.with_suffix('.exit.json'))
        row = d.verify_run(raw,log,argv,scene,index,variant,status['exit_code'])
        c.require(status == {k:row[k] for k in ('exit_code','command','diagnostics')}, f'D27 exit record differs: {log}')
        rows.append(row)
    recomputed = d.report(snapshot,summary['pairs'],rows)
    c.require(summary == recomputed, 'D27 summary differs from raw samples')
    c.require(not any(out.rglob('*.png')), 'D27 must not contain captures')
    c.require(recomputed['comparison']['a_pass'], 'D27 A exceeded its limits; preserve the failed timing evidence')
    return dict(results_sha256=c.sha(out/'summary.json'),**recomputed['comparison'])


def protected_assets(pin):
    result = {}
    for directory in ('assets/structures/retaining-wall-01','cities_do/assets/structures/retaining-wall-01'):
        paths = [p.decode('utf-8') for p in c.git('ls-tree','-r','--name-only','-z',c.BASE,'--',directory).split(b'\0')
                 if p and not p.endswith((b'.uid',b'.import'))]
        c.require(paths and not c.git('diff','--name-only','-z',c.BASE,'--',*paths), f'protected inputs changed: {directory}')
        for name in paths:
            relative = name.removeprefix('cities_do/')
            if name.startswith('cities_do/'):
                c.require(pin['projects']['baseline'][relative] == pin['projects']['candidate'][relative], f'protected copied asset changed: {name}')
            result[name] = c.digest(c.blob(name))
    return result


def prior_inputs(snapshot, root, pin, prior_snapshot, prior_functional, variant):
    c.require(bool(prior_snapshot) == bool(prior_functional),
              'prior baseline requires both snapshot and functional paths')
    if prior_snapshot is None:
        return snapshot, root, pin
    old_snapshot, old_root = map(c.scratch, (prior_snapshot, prior_functional))
    old = c.load_pin(old_snapshot)
    c.validate(old_snapshot, old, variant, live=True)
    fields = ('runtime', 'wrapper', 'wrapper_blob_sha256', 'env_blob_sha256')
    c.require(all(old[k] == pin[k] for k in fields) and
              old['projects'][variant] == pin['projects'][variant],
              f'prior {variant} project or runtime bytes differ')
    return old_snapshot, old_root, old


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--snapshot',required=True,type=Path)
    p.add_argument('--functional',required=True,type=Path)
    p.add_argument('--prior-baseline-snapshot', type=Path, help='original snapshot for an identical baseline run')
    p.add_argument('--prior-baseline-functional', type=Path, help='original result and raw log root for that baseline')
    p.add_argument('--candidate-headless-snapshot', type=Path, help='identical candidate snapshot from the headless run')
    p.add_argument('--candidate-headless-functional', type=Path, help='original candidate headless result and raw log root')
    p.add_argument('--warning-allowlist',type=Path)
    p.add_argument('--review-notes',required=True,type=Path)
    choice = p.add_mutually_exclusive_group(required=True)
    choice.add_argument('--d27',type=Path)
    choice.add_argument('--deferred-d27')
    args = p.parse_args()
    c.checkout_gate()
    snapshot,root,notes = map(c.scratch,(args.snapshot,args.functional,args.review_notes))
    pin = c.load_pin(snapshot)
    c.validate(snapshot,pin,'baseline','candidate',live=True)
    c.require(all(c.digest(c.overlay_input(name)) == digest for name,digest in pin['overlays'].items()),
              'final candidate overlay no longer matches the live unstaged files')
    allow = f.warnings(args.warning_allowlist)
    baseline = prior_inputs(snapshot, root, pin, args.prior_baseline_snapshot, args.prior_baseline_functional, 'baseline')
    headless = prior_inputs(snapshot, root, pin, args.candidate_headless_snapshot, args.candidate_headless_functional, 'candidate')
    suites = {('baseline',m):baseline for m in f.MODES if f.inventory('baseline',m)}
    suites.update({('candidate','headless'):headless, ('candidate','native-no-capture'):(snapshot,root,pin),
                   ('candidate','native-capture'):(snapshot,root,pin)})
    verification = {f'{v}/{m}':suite(src, reports, v, m, manifest, allow)
                    for (v,m), (src,reports,manifest) in suites.items()}
    note = notes.read_text(encoding='utf-8-sig')
    for name,digest in verification['candidate/native-capture']['captures'].items():
        c.require(any(name in line and digest in line and len(line.strip()) > len(name)+len(digest)+8 for line in note.splitlines()),
                  f'capture review line (name, hash, observation) missing: {name}')
    if args.deferred_d27:
        c.require(args.deferred_d27.strip() and args.deferred_d27 in note, 'explicit D27 deferral must appear in review notes')
        perf = dict(deferred=True,reason=args.deferred_d27)
    else:
        perf = performance(snapshot,c.scratch(args.d27))
    c.checkout_gate()
    print(json.dumps(dict(stage='E4b',branch=c.BRANCH,baseline=c.BASE,pin_sha256=c.sha(snapshot/'inputs.json'),
          protected_assets=protected_assets(pin),review_notes_sha256=c.sha(notes),functional=verification,
          baseline_evidence_pin_sha256=c.sha(baseline[0]/'inputs.json'),
          candidate_headless_evidence_pin_sha256=c.sha(headless[0]/'inputs.json'),
          d27=perf,timing_collection=not bool(args.deferred_d27)),indent=2,ensure_ascii=False))


if __name__ == '__main__':
    c.cli(main)
