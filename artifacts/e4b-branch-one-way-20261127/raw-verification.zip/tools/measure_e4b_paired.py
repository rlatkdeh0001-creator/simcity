"""E4b D27 only: alternate A baseline/candidate; record three candidate B samples."""
import argparse
from pathlib import Path
import re
import statistics

import e4b_common as c

A_LAYOUT = '15cc0ec9a47c7d9af2e559adf9f0950f8d5d23a59dcead092e733fd63eb1d14c'
SETTINGS = dict(method='gl_compatibility', driver='opengl3', width=1920, height=1080,
                fullscreen=True, vsync=False, max_fps=0, paused=True, seed=20261114,
                buildings=24, warmup_usec=1_000_000, sample_min_usec=4_000_000,
                zoom=.9, camera_world_cell=[48,48], camera_screen_point=[960,410])
LIMITS = {'mean_ms':1.10, 'p95_ms':1.15}


def schedule(pairs):
    c.require(type(pairs) is int and pairs >= 3, 'D27 requires at least three A pairs')
    variants = ('baseline','candidate')
    return [('A',i,v) for i in range(1,pairs+1) for v in (variants if i%2 else variants[::-1])] + [
            ('B',i,'candidate') for i in range(1,4)]


def sample(raw, scene):
    c.require(scene in ('A','B'), 'unknown D27 scene')
    expected = dict(SETTINGS, scene=scene, roads=6, vehicles=24, moving_vehicles=0, held_vehicles=24,
                    branch_widths_m=[], moving_by_branch=[])
    if scene == 'B':
        expected.update(roads=8, vehicles=27, moving_vehicles=3, branch_widths_m=[6,8], moving_by_branch=[1,2])
    for key,value in expected.items():
        c.require(type(raw.get(key)) is type(value) and raw[key] == value, f'D27 wrong {key}: {raw.get(key)!r}, expected {value!r}')
    layout = raw.get('layout_sha256','')
    c.require(re.fullmatch(r'[0-9a-f]{64}',layout) and (layout == A_LAYOUT if scene=='A' else layout != A_LAYOUT), 'D27 layout differed from the frozen workload')
    frames = raw['frame_usec']
    c.require(type(frames) is list and frames and len(frames) == raw['frames'] and type(raw['frames']) is int
              and all(type(x) is int and x > 0 for x in frames), 'D27 invalid frame intervals')
    elapsed = sum(frames)
    c.require(type(raw['elapsed_usec']) is int and elapsed == raw['elapsed_usec'] and elapsed >= SETTINGS['sample_min_usec']
              and elapsed-frames[-1] < SETTINGS['sample_min_usec'], 'D27 sample incomplete or sampled past its first eligible boundary')
    return elapsed/len(frames)/1000, sorted(frames)[(95*len(frames)+99)//100-1]/1000


def summarize(rows):
    medians = {}
    for scene,variant in (('A','baseline'), ('A','candidate'), ('B','candidate')):
        chosen = [r for r in rows if (r['scene'],r['variant']) == (scene,variant)]
        c.require(chosen, f'missing {scene}/{variant} samples')
        medians[f'{scene}/{variant}'] = {k:statistics.median(r[k] for r in chosen) for k in LIMITS}
    ratios = {key:medians['A/candidate'][key]/medians['A/baseline'][key] for key in LIMITS}
    return {'medians':medians, 'a_ratios':ratios, 'a_limits':LIMITS,
            'a_pass':all(ratios[key] <= LIMITS[key] for key in LIMITS), 'b_record_only':True}


def make_command(snapshot, directory, scene, index, variant):
    rel = c.BASE_FIXTURE if scene == 'A' else c.BRANCH_FIXTURE
    raw = directory/f'{scene.lower()}{index}-{variant}-frames.json'
    argv = c.command(snapshot,variant,95,['--rendering-method','gl_compatibility','--rendering-driver','opengl3',
              '--fullscreen','--resolution','1920x1080','--script','res://'+rel,'--',f'--frames-json={raw.as_posix()}'])
    return raw, directory/f'{scene.lower()}{index}-{variant}-godot.log', argv


def verify_run(raw_path, log, argv, scene, index, variant, exit_code):
    text = log.read_text(encoding='utf-8', errors='replace')
    diags = c.diagnostics(text)
    c.require(exit_code==0 and not diags, f'{log}: exit={exit_code}, diagnostics={diags}')
    lines = text.splitlines()
    marker = f'D27_PASS E4b scene={scene} method=gl_compatibility driver=opengl3'
    device = [line.strip() for line in lines if line.strip().startswith('OpenGL API ') and 'Using Device:' in line]
    engine = [line.strip() for line in lines if line.strip().startswith('Godot Engine v')]
    c.require(lines.count(marker)==1 and len(device)==len(engine)==1, f'{log}: no unambiguous pass/renderer/engine banner')
    raw = c.json_read(raw_path)
    mean,p95 = sample(raw,scene)
    return dict(scene=scene,index=index,variant=variant,exit_code=exit_code,diagnostics=diags,
                command=argv,device=device[0],engine=engine[0],layout_sha256=raw['layout_sha256'],
                frames=raw['frames'],elapsed_usec=raw['elapsed_usec'],mean_ms=mean,p95_ms=p95,
                frames_sha256=c.sha(raw_path),log_sha256=c.sha(log))


def report(snapshot, pairs, rows):
    c.require([(r['scene'],r['index'],r['variant']) for r in rows] == schedule(pairs), 'D27 incomplete or wrong order')
    c.require(len({(r['device'],r['engine']) for r in rows})==1 and len({r['layout_sha256'] for r in rows if r['scene']=='B'})==1,
              'D27 device, engine or B layout differed across runs')
    return dict(stage='E4b', pin_sha256=c.sha(snapshot/'inputs.json'), pairs=pairs, captures=0,
                comparison=summarize(rows), runs=rows)


def run(snapshot,out,pairs):
    pin = c.load_pin(snapshot)
    c.validate(snapshot,pin,'baseline','candidate',live=True)
    c.require(set(['core/city_model.gd','core/road_profile.gd']) <= pin['overlays'].keys(), 'D27 candidate lacks the explicit E4b model/profile overlays')
    for v,rel in (('baseline',c.BASE_FIXTURE),('candidate',c.BASE_FIXTURE),('candidate',c.BRANCH_FIXTURE)):
        c.entry_chain(snapshot/v/'cities_do',rel)
    # B API is intentionally not parsed by A. Fail before spending any A samples
    # if the proposed integration contract is absent from this candidate.
    project = snapshot/'candidate/cities_do'
    c.require(re.search(r'^func add_branch_one_way\(', (project/'core/city_model.gd').read_text(encoding='utf-8-sig'),re.M)
              and all(n in (project/'core/road_profile.gd').read_text(encoding='utf-8-sig') for n in ('BranchVariant','SIX_METRE','EIGHT_METRE')),
              'candidate branch producer/variant names missing')
    out.mkdir(exist_ok=False)
    rows = []
    for scene,index,variant in schedule(pairs):
        # Both comparisons warm/check the same variant's byte inventory outside sampling.
        c.validate(snapshot,pin,variant,live=True)
        raw,log,argv = make_command(snapshot,out,scene,index,variant)
        code,text = c.engine(snapshot,argv,log)
        c.json_new(log.with_suffix('.exit.json'),dict(exit_code=code,diagnostics=c.diagnostics(text),command=argv))
        c.validate(snapshot,pin,variant,live=True)
        row = verify_run(raw,log,argv,scene,index,variant,code)
        if rows:
            c.require((row['device'],row['engine']) == (rows[0]['device'],rows[0]['engine']), 'D27 device/engine changed during sampling')
        rows.append(row)
        print(f'{scene}{index}/{variant}: {row["mean_ms"]:.6f} ms mean / {row["p95_ms"]:.3f} ms p95',flush=True)
    c.validate(snapshot,pin,'baseline','candidate',live=True)
    result = report(snapshot,pairs,rows)
    c.json_new(out/'summary.json',result)
    print(result['comparison'])
    return 0 if result['comparison']['a_pass'] else 1


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--snapshot',required=True,type=Path)
    p.add_argument('--out',required=True,type=Path)
    p.add_argument('--pairs',type=int,default=3)
    p.add_argument('--authorize-d27',action='store_true',help='only after the timing window is explicitly authorized')
    args = p.parse_args()
    c.require(args.authorize_d27, 'D27 timing not authorized; no invocation made')
    schedule(args.pairs)
    snapshot,out = map(c.scratch,(args.snapshot,args.out))
    c.require(not out.is_relative_to(snapshot) and not snapshot.is_relative_to(out), 'D27 evidence must be separate from snapshot')
    with c.exclusive():
        return run(snapshot,out,args.pairs)


if __name__ == '__main__':
    c.cli(main)
