"""Engine-free checks for runner contracts; no subprocess can launch Godot here."""
import argparse
from hashlib import sha256
from pathlib import Path
import re
import tempfile
import unittest

import e4b_common as c
import measure_e4b_paired as d
import verify_e4b_branch_one_way as f


class Checks(unittest.TestCase):
    def test_matrix_is_stage_specific(self):
        self.assertEqual(len(f.inventory('baseline', 'headless')), 14)
        self.assertEqual(len(f.inventory('candidate', 'headless')), 18)
        self.assertIn(f.WORK_COUNT, f.inventory('candidate', 'headless'))
        self.assertEqual(f.inventory('baseline', 'native-no-capture'), ('test_one_way_road_ui',))
        self.assertEqual(f.inventory('candidate', 'native-no-capture'), ('test_one_way_road_ui', 'test_branch_one_way_ui'))
        self.assertEqual(f.inventory('candidate', 'native-capture'), ('test_branch_one_way_ui',))

    def test_zero_exit_partial_and_diagnostics(self):
        name = f.WORK_COUNT
        text = 'PASS perf: retained work counts\nRESULT 1/1 branch checks passed\n'
        self.assertEqual(f.review(name, text, 0), (1, 1))
        for bad, code in [(text, 1), ('PASS perf: partial', 0), (text + 'Fatal error.\n0xC0000005', 0),
                          (text + 'WARNING: ObjectDB instances leaked at exit', 0), (text + 'SCRIPT ERROR: bad', 0),
                          (text.replace('1/1', '1/2'), 0), (text.replace('perf:', 'other:'), 0)]:
            with self.assertRaises(ValueError):
                f.review(name, bad, code)

    def test_warning_allowlist_is_ordered_and_hard_failures_stay_fatal(self):
        name = 'test_one_way_road_ui'
        report = 'RESULT 2/2 road UI checks passed\n'
        a, b = 'WARNING: rail a', 'WARNING: rail b'
        self.assertEqual(f.review(name, a+'\n'+b+'\n'+report, 0, [a,b]), (2,2))
        for text in (report, b+'\n'+a+'\n'+report, 'ERROR: x\n'+report):
            with self.assertRaises(ValueError):
                f.review(name, text, 0, [a,b])

    def test_zoning_untimed_exact_anchor_and_traffic_opt_in(self):
        source = b'extends SceneTree\r\n' + ('\r\n'.join(f.ZONING_TIMING)+'\r\n\tcheck(true)\r\n').encode()
        self.assertEqual(f.untimed_zoning(source), b'extends SceneTree\r\n\tcheck(true)\r\n')
        with self.assertRaises(ValueError):
            f.untimed_zoning(source.replace(b'var started', b'var start_time'))
        with self.assertRaises(ValueError):
            f.untimed_zoning(source + b'Time.get_ticks_usec()')

    def test_entry_resolution_and_traversal(self):
        with tempfile.TemporaryDirectory(dir=c.HERE) as td:
            p = Path(td)
            (p/'base.gd').write_text('extends SceneTree\n')
            (p/'suite.gd').write_text('extends "res://base.gd"\n')
            self.assertEqual(c.entry_chain(p, 'suite.gd'), ('suite.gd','base.gd'))
            (p/'base.gd').write_text('extends "suite.gd"\n')
            with self.assertRaises(ValueError):
                c.entry_chain(p, 'suite.gd')
            for unsafe in ('../../elsewhere', 'X:/out', 'tests/../../escape', 'tests/a:alternate', 'tests\\x'):
                with self.assertRaises(ValueError):
                    c.relative(unsafe)

    def test_three_pairs_and_record_only_b(self):
        self.assertEqual(d.schedule(3), [('A', 1, 'baseline'), ('A', 1, 'candidate'), ('A', 2, 'candidate'),
            ('A', 2, 'baseline'), ('A', 3, 'baseline'), ('A', 3, 'candidate'),
            ('B', 1, 'candidate'), ('B', 2, 'candidate'), ('B', 3, 'candidate')])
        values = [(10.0, 20.0), (11.0, 23.0), (12.0, 23.1)]
        for avg, p95 in values:
            a = [{'scene':'A', 'variant':v, 'mean_ms':m, 'p95_ms':p} for v,m,p in
                 [('baseline', 10.0, 20.0), ('candidate', avg, p95)]]
            b = {'scene':'B', 'variant':'candidate', 'mean_ms':500., 'p95_ms':500.}
            self.assertEqual(d.summarize(a+[b])['a_pass'], avg <= 11.0 and p95 <= 23.0)

    def test_raw_sample_negative_controls(self):
        frames = [5000]*776 + [6000]*20
        row = dict(d.SETTINGS, scene='A', layout_sha256=d.A_LAYOUT, roads=6, vehicles=24,
                   moving_vehicles=0, held_vehicles=24, branch_widths_m=[], moving_by_branch=[], frames=len(frames),
                   elapsed_usec=sum(frames), frame_usec=frames)
        self.assertEqual(d.sample(row, 'A'), (sum(frames)/len(frames)/1000, 5.0))
        for bad in (dict(row, frames=1), dict(row, elapsed_usec=1), dict(row, layout_sha256='f'*64),
                    dict(row, frame_usec=[True]*len(frames)), dict(row, vsync=True)):
            with self.assertRaises(ValueError):
                d.sample(bad, 'A')

    def test_anchor_hash(self):
        self.assertEqual(sha256(b'e4b').hexdigest(), c.digest(b'e4b'))


def integration(snapshot):
    pin = c.load_pin(snapshot)
    c.validate(snapshot,pin,'baseline','candidate',live=True)
    c.require((pin['projects']['baseline'][c.BASE_FIXTURE],pin['projects']['candidate'][c.BRANCH_FIXTURE]) ==
              (c.sha(c.HERE/'measure_e4b_a.gd'),c.sha(c.HERE/'measure_e4b_b.gd')), 'prepared fixture scripts are stale')
    base = snapshot/'baseline/cities_do'
    cand = snapshot/'candidate/cities_do'
    with tempfile.TemporaryDirectory(dir=c.HERE) as td:
        root = Path(td)
        entries = f.preflight(base, f.REGRESSIONS + ('test_one_way_render',), 'headless', root)
        assert tuple(entries['test_road_profile_connections']['entry_sha256']) == (
            'tests/test_road_profile_connections.gd','tests/test_road_midpoint_connections.gd')
        assert c.entry_chain(base,c.BASE_FIXTURE) == (c.BASE_FIXTURE,)
        assert c.entry_chain(cand,c.BRANCH_FIXTURE) == (c.BRANCH_FIXTURE,c.BASE_FIXTURE)
        assert (base/c.BASE_FIXTURE).read_bytes() == (cand/c.BASE_FIXTURE).read_bytes()
        assert not re.search(r'BranchVariant|add_branch_one_way', (base/c.BASE_FIXTURE).read_text(encoding='utf-8'))
        args = d.make_command(snapshot,root,'A',1,'baseline')[2]
        assert args[args.index('--script')+1] == f'res://{c.BASE_FIXTURE}' and '--headless' not in args
        assert '--headless' not in d.make_command(snapshot,root,'B',1,'candidate')[2]
        assert '--max-fps' not in args and '--quit-after' not in args
    print(f'Offline integration: {len(entries)} authored predecessor entries, A/B inheritance, identical A bytes, cache/runtime pin and launch arguments verified')


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--snapshot', type=Path, help='optional prepared snapshot to check without launching')
    args = parser.parse_args()
    result = unittest.main(verbosity=2, argv=[__file__], exit=False).result
    if not result.wasSuccessful():
        raise SystemExit(1)
    if args.snapshot:
        integration(c.scratch(args.snapshot))
