"""E4b affected functional matrix only. No imports, builds, benchmarks or default captures."""
import argparse
from pathlib import Path
import re
import struct

import e4b_common as c

OWN = ('test_branch_one_way', 'test_branch_one_way_ui')
WORK_COUNT = 'test_branch_one_way_retained'
REGRESSIONS = tuple('test_' + n for n in '''one_way_roads one_way_road_ui road_width_grades road_transition_marks
    road_continue road_seams road_profile_connections traffic scheduled_buses bus_stop_host road_parcels
    roads_zoning road_demolition_model demolition'''.split())
NATIVE = ('test_one_way_road_ui', OWN[1])
MODES = ('headless','native-no-capture','native-capture')
CAPTURES = {'kinds':'e4b-branch-kinds-1920.png', 'continue':'e4b-branch-continue-1920.png'}
ZONING = 'test_roads_zoning'
ZONING_TIMING = ('\tvar started := Time.get_ticks_msec()',
                 '\tprint("1024-map short-stroke zoning update ms: ",Time.get_ticks_msec()-started)')
TIMING = re.compile(r'get_ticks_|get_frames_per_second|frame_post_draw|BENCHMARK', re.I)
FINAL_COUNT = re.compile(r'^RESULT\s+(\d+)\s*/\s*(\d+)\s+.+ checks? passed\s*$', re.M)
SPECIAL = {'test_scheduled_buses':'SCHEDULED_BUSES', 'test_bus_stop_host':'BUS_STOP_HOST'}
RAIL_WARNING_LINES = {
    "WARNING: Loaded resource as image file, this will not work on export: "
    f"'res://assets/rail/rail-track-01/{name}'. Instead, import the image file as an Image resource and load it normally as a resource."
    for name in ('strip.png','strip_end.png','strip_rails.png')
}
NATIVE_FLAGS = ['--rendering-method','gl_compatibility','--rendering-driver','opengl3',
                '--fullscreen','--resolution','1920x1080','--max-fps','30','--quit-after','5500']


def inventory(variant, mode):
    if mode == 'headless':
        return REGRESSIONS if variant == 'baseline' else (*OWN, WORK_COUNT, *REGRESSIONS, 'test_one_way_render')
    if mode == 'native-no-capture':
        return NATIVE[:1] if variant == 'baseline' else NATIVE
    return () if variant == 'baseline' else (OWN[1],)


def untimed_zoning(raw):
    newline = b'\r\n' if b'\r\n' in raw else b'\n'
    for line in ZONING_TIMING:
        anchor = line.encode() + newline
        c.require(raw.count(newline+anchor) == 1, 'zoning timing anchors changed; review before any launch')
        raw = raw.replace(newline+anchor, newline, 1)
    c.require(not TIMING.search(raw.decode('utf-8-sig')), 'unreviewed timing code in zoning')
    return raw


def preflight(project, names, mode, directory):
    scripts = {}
    for name in names:
        rel = f'tests/{name}.gd'
        chain = c.entry_chain(project, rel)
        files = {part: (project/part).read_bytes() for part in chain}
        raw = files[rel]
        script = rel
        if name == ZONING:
            script_path = directory/'untimed-test_roads_zoning.gd'
            run_bytes = untimed_zoning(raw)
            script_path.write_bytes(run_bytes)
            script = script_path.as_posix()
        else:
            run_bytes = raw
        for part, content in files.items():
            source = (run_bytes if part == rel else content).decode('utf-8-sig')
            for line in source.splitlines():
                if line.lstrip().startswith('#') or not TIMING.search(line):
                    continue
                if name == 'test_traffic' and part == rel:
                    c.require('"--benchmark-traffic" in OS.get_cmdline_user_args()' in source,
                              'traffic benchmark argument gate changed')
                    continue
                # frame_post_draw is a graphics fence, not a clock. Capture output
                # is still checked separately and passed only to the candidate UI.
                c.require(not TIMING.search(line.replace('frame_post_draw','')), f'unreviewed timing in {part}: {line}')
        if name == OWN[1] and mode == 'native-capture':
            source = raw.decode('utf-8-sig')
            definitions = all(f'"{key}": "{value}"' in source for key,value in CAPTURES.items())
            parser = 'var prefix := "--e4b-%s-capture=" % name_value' in source and 'arg.begins_with(prefix)' in source
            c.require(definitions and parser, 'candidate UI fixture lacks the expected E4b capture names or parser')
        scripts[name] = {'source_sha256':c.digest(raw), 'entry_sha256':{p:c.digest(b) for p,b in files.items()},
                         'script_sha256':c.digest(run_bytes), 'script':script if name == ZONING else 'res://'+script}
    return scripts


def review(name, text, code, allowance=()):
    diags = c.diagnostics(text)
    c.require(code == 0 and not any(c.FATAL.search(line) for line in diags), f'{name}: exit {code}, hard diagnostic(s): {diags}')
    c.require(diags == list(allowance), f'{name}: diagnostics differ from frozen ordered warnings: {diags}')
    c.require(not re.search(r'^BENCHMARK\b|^1024-map short-stroke zoning update ms:', text, re.M|re.I), f'{name}: timing output in functional log')
    if name in SPECIAL:
        matches = re.findall(fr'^{SPECIAL[name]} checks=\s*(\d+) failed=\s*(\d+)\s*$', text, re.M)
        c.require(len(matches) == 1, f'{name}: missing or duplicate completion marker')
        total, failed = map(int,matches[0])
        passed = total-failed
    else:
        matches = FINAL_COUNT.findall(text)
        c.require(len(matches) == 1, f'{name}: missing or duplicate RESULT count')
        passed, total = map(int,matches[0])
    c.require(0 < passed == total, f'{name}: incomplete assertions {passed}/{total}')
    if name == WORK_COUNT:
        c.require(re.search(r'^PASS\s+perf:', text, re.M), f'{name}: missing perf work-count checks')
    return passed,total


def capture_facts(directory, mode):
    expected = set(CAPTURES.values()) if mode == 'native-capture' else set()
    found = {p.relative_to(directory).as_posix() for p in directory.rglob('*.png')}
    c.require(found == expected, f'expected capture set {sorted(expected)}; got {sorted(found)}')
    results = {}
    for name in sorted(expected):
        path = c.checked(directory, name)
        with path.open('rb') as f:
            header = f.read(24)
        c.require(header[:16] == b'\x89PNG\r\n\x1a\n\x00\x00\x00\rIHDR' and len(header) == 24
                  and struct.unpack('>II',header[16:]) == (1920,1080), f'invalid 1920x1080 PNG: {path}')
        results[name] = c.sha(path)
    return results


def warnings(path):
    if path is None:
        return {}
    data = c.json_read(c.scratch(path))
    c.require(data['baseline'] == c.BASE, 'warning allowlist is not pinned to E4b baseline')
    rows = data['warnings']
    for key, lines in rows.items():
        mode, name = key.split('/')
        c.require(mode in MODES[:2] and name in inventory('baseline',mode) and type(lines) is list and lines
                  and all(type(line) is str and line in RAIL_WARNING_LINES for line in lines), f'unsafe warning allowance: {key}')
    return rows


def allowance_for(allowances,mode,name):
    return allowances.get(f'{mode}/{name}', [])


def run(snapshot, out, variant, mode, names, allow, red=False):
    pin = c.load_pin(snapshot)
    c.validate(snapshot,pin,variant,live=True)
    project = snapshot/variant/'cities_do'
    if variant == 'candidate' and not red:
        c.require(set(f'tests/{n}.gd' for n in (*OWN,WORK_COUNT)) <= pin['overlays'].keys(), 'final snapshot lacks explicit E4b model/UI/work-count tests')
    if mode == 'native-capture':
        probe = c.json_read(out.parent/'native-no-capture'/'results.json')
        c.require((probe['pin_sha256'], probe['variant'], probe['mode'], probe['expected']) ==
                  (c.sha(snapshot/'inputs.json'), 'candidate', 'native-no-capture', list(NATIVE))
                  and len(probe['rows']) == len(NATIVE), 'matching complete native no-capture probe is required first')
        for name,row in zip(NATIVE,probe['rows']):
            log = c.checked(out.parent/'native-no-capture',name+'.log')
            c.require(row['name'] == name and c.sha(log) == row['log_sha256'], 'native no-capture evidence log differs')
            review(name, log.read_text(encoding='utf-8',errors='replace'), row['exit_code'], allowance_for(allow,'native-no-capture',name))
        capture_facts(out.parent/'native-no-capture','native-no-capture')
    if not red:
        out.mkdir(exist_ok=False)
    scripts = preflight(project,names,mode,out)
    rows = []
    for name in names:
        c.validate(snapshot,pin,variant)
        details = scripts[name]
        flags = ['--headless'] if mode == 'headless' else NATIVE_FLAGS[:]
        flags += ['--script', details['script']]
        if mode == 'native-capture':
            flags += ['--', *(f'--e4b-{key}-capture={(out/value).as_posix()}' for key,value in CAPTURES.items())]
        argv = c.command(snapshot,variant,240,flags)
        log = None if red else out/(name+'.log')
        if name == ZONING:
            c.require(c.sha(Path(details['script'])) == details['script_sha256'], 'untimed redirect changed before run')
        code,text = c.engine(snapshot,argv,log)
        if red:
            print(text, end='', flush=True)
        if name == ZONING:
            c.require(c.sha(Path(details['script'])) == details['script_sha256'], 'untimed redirect changed during run')
        c.validate(snapshot,pin,variant)
        counts = review(name,text,code,allowance_for(allow,mode,name))
        if not red:
            row = dict(name=name, exit_code=code, log_sha256=c.sha(log), counts=list(counts),
                       diagnostics=c.diagnostics(text), command=argv, **details)
            # Never infer a whole-run pass from progress rows; results.json is
            # written only after the planned mode completes and is rechecked.
            c.json_new(out/(name+'.result.json'), dict(pin_sha256=c.sha(snapshot/'inputs.json'),
                       variant=variant, mode=mode, row=row))
            rows.append(row)
        print(f'{mode}/{name}: {counts[0]}/{counts[1]}', flush=True)
    if not red:
        c.validate(snapshot,pin,variant,live=True)
        c.json_new(out/'results.json', dict(stage='E4b', variant=variant, mode=mode, expected=list(names), rows=rows,
                   pin_sha256=c.sha(snapshot/'inputs.json'), captures=capture_facts(out,mode)))


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--snapshot',type=Path,required=True)
    p.add_argument('--out',type=Path,help='scratch report root, separate from snapshot')
    p.add_argument('--variant',choices=('baseline','candidate'),default='candidate')
    p.add_argument('--mode',choices=MODES,default='headless')
    p.add_argument('--tests',nargs='+')
    p.add_argument('--warning-allowlist',type=Path)
    p.add_argument('--red',action='store_true',help='explicit feature suites only, no evidence saved')
    p.add_argument('--allow-engine',action='store_true',help='only when launch is separately authorized')
    args = p.parse_args()
    names = tuple(args.tests or inventory(args.variant,args.mode))
    c.require(names and len(names)==len(set(names)) and set(names)<=set(inventory(args.variant,args.mode)), 'unexpected test/mode/variant inventory')
    c.require(not args.red or (args.tests and set(names)<=set((*OWN,WORK_COUNT)) and args.variant=='candidate'
              and args.mode!='native-capture' and not args.out), 'RED requires explicit candidate feature tests, no captures/out')
    c.require(args.allow_engine, 'engine not authorized; no invocation made')
    snapshot = c.scratch(args.snapshot)
    out = None
    if not args.red:
        c.require(args.out, '--out required for persisted evidence')
        root = c.scratch(args.out)
        c.require(not root.is_relative_to(snapshot) and not snapshot.is_relative_to(root), 'report must be separate from the snapshot')
        out = root/args.variant/args.mode
    allow = warnings(args.warning_allowlist)
    if out is not None:
        out.parent.mkdir(parents=True,exist_ok=True)
    with c.exclusive():
        run(snapshot,out,args.variant,args.mode,names,allow,args.red)


if __name__ == '__main__':
    c.cli(main)
