"""Road marking v2: pinned baseline, three real frames with native-pixel crops, D27 scene A only."""
import argparse
from pathlib import Path
import re
import statistics
import struct

import e4b_common as c
import measure_e4b_paired as d

c.BASE = '0e205e349003158753dc2a5c3bf8c9b155e85540'
CROP = {
    'e4a-one-way-kinds': (330, 180, 1040, 550),
    'e4b-branch-kinds': (435, 125, 890, 515),
    'e4b-branch-continue': (610, 130, 675, 335),
}
ZOOM03 = 'e4b-branch-continue-zoom030-crop-v2.png'
ZOOM03_RECT = (800, 345, 320, 220)
ENTRIES = {
    'a': ('test_one_way_road_ui', 'e4a', {'kinds': 'e4a-one-way-kinds'}, 420),
    'b': ('test_branch_one_way_ui', 'e4b', {'kinds': 'e4b-branch-kinds', 'continue': 'e4b-branch-continue'}, 240),
}


def replace(text, anchor, replacement):
    c.require(text.count(anchor)==1, f'fixture anchor drift: {anchor!r}')
    return text.replace(anchor,replacement,1)


def filename(file,crop=False):
    return file+('-1920-crop-v2.png' if crop else '-1920-v2.png')


def stable_grid_click(text):
    # A real viewport click still uses the game's callbacks. Only the fixture's
    # stationary grid click stops yielding to physical OS motion mid-gesture.
    text = replace(text, 'func mouse_move(p: Vector2, mask := 0) -> void:',
                   'func mouse_move(p: Vector2, mask := 0, wait_frame := true) -> void:')
    text = replace(text, 'func button(p: Vector2, down: bool, which := MOUSE_BUTTON_LEFT) -> void:',
                   'func button(p: Vector2, down: bool, which := MOUSE_BUTTON_LEFT, wait_frame := true) -> void:')
    text = replace(text, ' root.push_input(e, true)\n await process_frame\n\nfunc button(',
                   ' root.push_input(e, true)\n if wait_frame: await process_frame\n\nfunc button(')
    text = replace(text, ' root.push_input(e, true)\n await process_frame\n\nfunc click(',
                   ' root.push_input(e, true)\n if wait_frame: await process_frame\n\nfunc click(')
    return replace(text, ' await click(control.get_global_rect().get_center())\n return true\n\nfunc node_named',
                   ' if control.name == &"RoadGridToggle":\n'
                   '  var target := control.get_global_rect().get_center()\n'
                   '  await mouse_move(target, 0, false)\n'
                   '  await button(target, true, MOUSE_BUTTON_LEFT, false)\n'
                   '  await button(target, false, MOUSE_BUTTON_LEFT, false)\n'
                   '  await settle()\n'
                   ' else:\n'
                   '  await click(control.get_global_rect().get_center())\n return true\n\nfunc node_named')


def fixture(path, role):
    _,_,tags,_ = ENTRIES[role]
    text = path.read_text(encoding='utf-8-sig')
    for tag,file in tags.items():
        text = replace(text,f'"{tag}": "{file}-1920.png"', f'"{tag}": "{filename(file)}"')
    if role=='a':
        text = stable_grid_click(text)
        text = replace(text,' "draw": "e4a-one-way-draw-1920.png",\n','')
        text = replace(text,'outputs.size() == 2 and DisplayServer', 'outputs.size() == CAPTURES.size() and DisplayServer')
    else:
        text = replace(text, '  images["continue"] = image\n continue_done',
                       '  images["continue"] = image\n'
                       '  var saved_origin: Vector2 = game.origin\n'
                       '  var saved_zoom: float = game.map_zoom\n'
                       '  game.map_zoom = .3\n'
                       '  game.origin = Vector2.ZERO\n'
                       '  game.origin = Vector2(960,455)-game.screen(Vector2(53.25,46.75))\n'
                       '  game.refresh(); await settle()\n'
                       '  var low := await frame()\n'
                       '  game.map_zoom = saved_zoom; game.origin = saved_origin\n'
                       '  game.refresh(); await settle()\n'
                       f'  if low != null: images["zoom03"] = low.get_region(Rect2i{ZOOM03_RECT})\n'
                       ' continue_done')
    # Invoke this only after a successfully saved full framebuffer. The crop
    # comes from the Image, not from a resized or recaptured viewport.
    anchor = ('  if not check(img.save_png(outputs[tag]) == OK, "save actual 1920x1080 framebuffer: " + str(outputs[tag])): return\n' if role=='a' else
              '  if not check(image.save_png(outputs[name_value]) == OK, "saved requested raw framebuffer: " + str(outputs[name_value])):\n   return\n')
    tag_name,img = ('tag','img') if role=='a' else ('name_value','image')
    rects = ', '.join(f'"{tag}": Rect2i{CROP[file]}' for tag,file in tags.items())
    code = (f'  var rect: Rect2i = {{{rects}}}[{tag_name}]\n'
            f'  var output: String = str(outputs[{tag_name}]).replace("-1920-v2.png", "-1920-crop-v2.png")\n'
            f'  var crop: Image = {img}.get_region(rect)\n'
            '  if not check(crop.get_size() == rect.size and not FileAccess.file_exists(output) and not DirAccess.dir_exists_absolute(output) and crop.save_png(output) == OK, "native-pixel crop saved: " + output): return\n')
    if role=='b':
        code += ('  if name_value == "continue":\n'
                 f'   var low_path := str(outputs[name_value]).get_base_dir().path_join("{ZOOM03}")\n'
                 '   var low: Image = images.get("zoom03")\n'
                 f'   if not check(low != null and low.get_size() == Vector2i{ZOOM03_RECT[2:]} and fresh(low_path) and low.save_png(low_path) == OK, "zoom .3 confirmation crop saved: " + low_path): return\n')
    return replace(text,anchor,anchor+code).encode('utf-8')


def png(path,dimension):
    with path.open('rb') as stream:
        header = stream.read(24)
    c.require(header[:8]==b'\x89PNG\r\n\x1a\n' and header[12:16]==b'IHDR' and struct.unpack('>II',header[16:24])==dimension,f'wrong PNG geometry: {path}')
    return dict(sha256=c.sha(path), size=list(dimension))


def captures(snapshot,out,rehearsal=False):
    pin = c.load_pin(snapshot)
    c.validate(snapshot,pin,'candidate',live=True)
    project = snapshot/'candidate/cities_do'
    rows = []
    with c.exclusive():
        out.mkdir(exist_ok=False)
        for role,(name,prefix,tags,minimum) in ENTRIES.items():
            source = project/'tests'/f'{name}.gd'
            entry = out/f'{name}-capture-fixture.gd'
            with entry.open('xb') as file:
                file.write(fixture(source,role))
            opts = ['--fixture-check'] if rehearsal else [f'--{prefix}-{tag}-capture={(out/filename(file)).as_posix()}' for tag,file in tags.items()]
            c.entry_chain(project, f'tests/{name}.gd')
            c.validate(snapshot,pin,'candidate',live=True)
            cmd = c.command(snapshot,'candidate',240,['--rendering-method','gl_compatibility','--rendering-driver','opengl3',
                  '--fullscreen','--resolution','1920x1080','--max-fps','30','--quit-after','5500','--script',entry.as_posix(),'--',*opts])
            log = out/f'{name}.log'
            code,text = c.engine(snapshot,cmd,log)
            marks = [(int(a),int(b)) for a,b in re.findall(r'^RESULT\s+(\d+)/(\d+) .+checks passed\s*$',text,re.M)]
            device = [line for line in text.splitlines() if line.startswith('OpenGL API ') and 'Using Device:' in line]
            diags = c.diagnostics(text)
            c.json_new(out/f'{name}.result.json',dict(command=cmd,exit=code,counts=marks,device=device,diagnostics=diags))
            c.require(code==0 and not diags and len(marks)==1 and marks[0][0]==marks[0][1]>=minimum and len(device)==1,
                      f'{name}: capture rejected: exit {code}, marks={marks}, diagnostics={diags}, device={device}')
            expected_crops=0 if rehearsal else len(tags)
            c.require(sum(s.startswith('PASS native-pixel crop saved: ') for s in text.splitlines())==expected_crops, 'unexpected crop success markers')
            rows.append(dict(test=name,command=cmd,counts=marks[0],device=device[0],log_sha256=c.sha(log),test_sha256=c.sha(source),executed_sha256=c.sha(entry)))
            print(name,marks[0],flush=True)
    c.validate(snapshot,pin,'candidate',live=True)
    expected = set() if rehearsal else {ZOOM03, *(filename(file,crop) for file in CROP for crop in (False,True))}
    c.require({p.name for p in out.glob('*.png')}==expected,'unexpected capture set')
    artifacts = {}
    for file,rect in (() if rehearsal else CROP.items()):
        artifacts[filename(file)] = png(out/filename(file),(1920,1080))
        artifacts[filename(file,True)] = dict(png(out/filename(file,True),rect[2:]),source=filename(file),rect=rect,scaling='none')
    if not rehearsal:
        artifacts[ZOOM03] = dict(png(out/ZOOM03,ZOOM03_RECT[2:]),zoom=.3,rect=ZOOM03_RECT,scaling='none',status='confirmation-pending')
    c.json_new(out/'summary.json',dict(pin_sha256=c.sha(snapshot/'inputs.json'),rehearsal=rehearsal,captures=artifacts,suites=rows))


def d27(snapshot,out):
    pin = c.load_pin(snapshot)
    c.validate(snapshot,pin,'baseline','candidate',live=True)
    c.require(pin['projects']['baseline'][c.BASE_FIXTURE]==pin['projects']['candidate'][c.BASE_FIXTURE],'A script bytes differ')
    rows = []
    with c.exclusive():
        out.mkdir(exist_ok=False)
        for scene,index,variant in (job for job in d.schedule(3) if job[0]=='A'):
            c.validate(snapshot,pin,variant,live=True)
            raw,log,argv = d.make_command(snapshot,out,scene,index,variant)
            code,text = c.engine(snapshot,argv,log)
            c.json_new(log.with_suffix('.exit.json'),dict(exit_code=code,diagnostics=c.diagnostics(text),command=argv))
            row = d.verify_run(raw,log,argv,scene,index,variant,code)
            c.require(not rows or (row['engine'],row['device'])==(rows[0]['engine'],rows[0]['device']),'A device or engine changed')
            rows.append(row)
            print(f'A{index}/{variant}: {row["mean_ms"]:.6f} ms mean / {row["p95_ms"]:.3f} ms p95',flush=True)
    c.validate(snapshot,pin,'baseline','candidate',live=True)
    medians = {v:{metric:statistics.median(r[metric] for r in rows if r['variant']==v) for metric in d.LIMITS}
               for v in ('baseline','candidate')}
    ratios = {metric:medians['candidate'][metric]/medians['baseline'][metric] for metric in d.LIMITS}
    passed = all(x<=d.LIMITS[k] for k,x in ratios.items())
    c.json_new(out/'summary.json',dict(stage='road-marking-v2',scene='A',pairs=3,pin_sha256=c.sha(snapshot/'inputs.json'),
                       medians=medians,ratios=ratios,limits=d.LIMITS,passed=passed,runs=rows))
    print(medians,ratios,passed,flush=True)
    return 0 if passed else 1


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('mode',choices=('offline','prepare','rehearsal','captures','d27'))
    p.add_argument('--snapshot',type=Path)
    p.add_argument('--out',type=Path)
    p.add_argument('--overlay',action='append',default=[])
    a = p.parse_args()
    c.checkout_gate()
    if a.mode=='offline':
        for role,(name,_,tags,_) in ENTRIES.items():
            path = c.ROOT/'cities_do/tests'/f'{name}.gd'
            output = fixture(path,role)
            c.require(all(filename(file).encode() in output for file in tags.values()) and b'get_region(rect)' in output and b'e4a-one-way-draw-1920.png' not in output,'bad output-only fixture')
            print(role,'test input',c.sha(path),'capture fixture script',c.digest(output),flush=True)
        return 0
    snapshot = c.scratch(a.snapshot)
    if a.mode=='prepare':
        c.require('core/road_geometry.gd' in a.overlay,'missing marking production overlay')
        c.prepare(snapshot,a.overlay)
        return 0
    out = c.scratch(a.out)
    c.require(not out.exists(),'output already exists')
    if a.mode in ('rehearsal','captures'):
        return captures(snapshot,out,rehearsal=a.mode=='rehearsal')
    return d27(snapshot,out)

if __name__=='__main__':
    c.cli(main)
